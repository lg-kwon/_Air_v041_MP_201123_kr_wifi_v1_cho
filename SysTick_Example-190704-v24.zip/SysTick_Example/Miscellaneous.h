#ifndef __MISCELLANEOUS_H
#define __MISCELLANEOUS_H

#include "main.h"

int g_voicePortDelay;
unsigned int voicePlayFlag;

unsigned int consumableCheck();
void voicePortInit();
void voicePlay(unsigned int voice, unsigned int delay);

#endif