#ifndef __HANDLER_H
#define __HANDLER_H

#include "main.h"

/* Value Types  ------------------------------------------------------------*/
extern unsigned int currentState;
extern unsigned int isFirstEntrance;
extern unsigned int isReadyEntrance;
extern unsigned int g_remoteFlag;
extern SYSTEMINFO sysConfig;
extern PLASMAINFO plasmaInfo;
extern DISINFO disInfo;
extern IONINFO ionInfo;
extern unsigned int segBlinkOnTime;

extern unsigned int G1_SF;
extern unsigned int G2_SF;
extern unsigned int G3_SF;
extern unsigned int G4_SF;

extern unsigned char pidDetect;
/* Function Types  ------------------------------------------------------------*/
void handler();

extern unsigned int consumableCheck();

extern void control_sterOn();
extern void control_sterOff();
extern void control_Blink_sterOff();
extern void control_IonOn();
extern void control_IonOff();
extern void control_ledFont();
extern void control_initLed();
extern void control_disLed();
extern void segmentOff();
extern void control_relayAllOff();
extern void control_relayDestruction();
extern void control_desLed();
extern void control_sterStartLedOn();
extern void control_sterStopLedOn();
extern void control_consumableCheckLed();
extern void systemWrite();

//Disinfect
extern void control_disRelayOn();
extern void control_disRelayOff();
extern void control_disLed();

//Ion
extern void control_IonOn();
extern void control_IonOff();
extern void control_ionLed();

//timer
extern int prepareTimer;
extern int destructionTimer;

//plasma blink
extern unsigned int plasmaBlinkOn;
extern unsigned int plasmaBlinkOnTimer;
extern unsigned int plasmaBlinkOnFlag;
extern unsigned int plasmaBlinkOffTimer;
extern unsigned int plasmaBlinkOffFlag;

extern unsigned int pidLEDOnFlag;

#ifdef  STAND_TYPE_ENABLE
extern unsigned int fanBlinkOn;
extern unsigned int fanBlinkOnTimer;
extern unsigned int fanBlinkOnFlag;
extern unsigned int fanBlinkOffTimer;
extern unsigned int fanBlinkOffFlag;
#endif

unsigned char sterOzoneDetectFlag;
extern double dOzoneSensoredValue;

//void
extern void voicePlay(unsigned int voice, unsigned int delay);

//engineer
extern void control_engineerLed();
unsigned int g_prvOzoneValue;
#endif