/**
  ******************************************************************************
  * @file    SysTick/SysTick_Example/main.h 
  * @author  
  * @version V1.0.0
  * @date    30-September-2011
  * @brief   Header for main.c module
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 HealthWell Medical</center></h2>
  ******************************************************************************  
  */ 

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "stm324xg_eval.h"
#include "Peripheral.h"
#include "24LC512.h"
#include "Key.h"
#include "relay.h"
#include "RTC.h"
#include "LED.h"
#include "remote.h"
#include "isd1760.h"
#include "pir.h"
#include "eeprom.h"
//#include "handler.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define SJM_DEBUG
  #ifdef SJM_DEBUG
    #define SW_VERSION                  24      //0.7
  #else
    #define SW_VERSION                  21      //0.7
  #endif

//#define UNIFY_SOURCE                  // SJM 190626 

#define PIR_SENSOR_ENABLE
#define OZONE_SENSOR_ENABLE
//#define MEDICA_EXPO
//#define STAND_TYPE_ENABLE
#define WALL_TYPE_ENABLE

#define ADD_REMOTE_OZONE_SENSOR
//#define OZONE_DEPENDENT_DESTRUCTION
//#define BACTERIA_FLOATING_TEST_RELEASE
#define CHECK_OZONE_LIMIT
//#define REPLACE_AC_FAN1_TO_PLASMA

#define CHANGE_DEFAULAT_MODE

#define INCLUDE_REMOTE_ACK        // SJM 190620 add key sound for acknowledge

//#define ENGLISH_VOICE             // SJM 190621
#define INCLUDE_BD_DEBUG          // SJM 190703 BD debugging routine
#define INCLUDE_TIME_SETTING      // SJM 190704 Time Setting Mode

/* Handler Types  ------------------------------------------------------------*/
#define STATE_INIT                  1
#define STATE_READY_STER            2
#define STATE_STER                  3
#define STATE_READY_DIS             4
#define STATE_DIS                   5
#define STATE_READY_ION             6
#define STATE_ION                   7
#define STATE_POWER_OFF             8
#define STATE_STER_STOP             9
#define STATE_DIS_STOP              10
#define STATE_ION_STOP              11
#define STATE_CONSUMABLE_WARNING    12
#define STATE_DESTRUCTION           13
#define STATE_PREPARE               14
#define STATE_ENGINEER_MODE         15
#define STATE_STER_TIME_SET         16
#ifdef  INCLUDE_BD_DEBUG
  #define STATE_BD_DEBUG            17
#endif
#ifdef  INCLUDE_TIME_SETTING
  #define STATE_TIME_SETTING        18
#endif
#define LAST_STATE                  17      // SJM 190703 it should revised when new State added.

#define PLASMA_MODE_START           1
#define PLASMA_MODE_READY           2
#define PLASMA_MODE_STOP            3
#define PLASMA_MODE_RESERVE         4

/* Exported types ------------------------------------------------------------*/
#define FALSE 0
#define TRUE  1

#define MODE_STER   1
#define MODE_DIS    2
#define MODE_ION    3

#define SETTING_NONE      0
#define SETTING_RESERVE   1
#define SETTING_POWER     2
#define SETTING_PID       3

/* Consumables Define ------------------------------------------------------------*/
/* 2016.12.13. DH Kwon Requested
#define CHANGE_OZONE_LAMP     4000
#define CHANGE_UV_LAMP        4000
#define CHANGE_FILTER         4000
*/

#define CHANGE_OZONE_LAMP     25000
#define CHANGE_UV_LAMP        8000
//#define CHANGE_FILTER         4000


/*2016.12.13. DH Kwon Requested
#define WARNING_NUMBER        3
*/
#define WARNING_NUMBER        2

#define WARNING_OZONE_LAMP    0x0001
#define WARNING_UV_LAMP       0x0002

/*2016.12.13. DH Kwon Requested
#define WARNING_FILTER        0x0004
*/

#ifdef  MEDICA_EXPO
  #define PLASMA_BLINK_ON_TIME  10  // 10sec
  #define PLASMA_BLINK_OFF_TIME 120  // 120sec
#else
  #define PLASMA_BLINK_ON_TIME  30  //10sec
  #define PLASMA_BLINK_OFF_TIME 30   //sec
#endif

#ifdef  STAND_TYPE_ENABLE
  #define FAN_BLINK_ON_TIME  300   // 5min
  #define FAN_BLINK_OFF_TIME 60   // 1min
#endif

typedef struct
{
  unsigned char pidOn;
  int rsvTime;
  unsigned char pwr;
  unsigned char rsvOn;
  unsigned int modeSelect;
  unsigned int blinkOnTimer;
  unsigned int blinkOffTimer;
  unsigned char blinkOnFlag;
  unsigned char blinkOffFlag;
  unsigned int Mode;
  unsigned int plasmaOneSec;
  unsigned int plasmaTimer;
  unsigned int continuation;
}PLASMAINFO;

typedef struct
{
  unsigned int blinkOnTimer;
  unsigned int blinkOffTimer;
  unsigned char blinkOnFlag;
  unsigned char blinkOffFlag;
  unsigned int disOneSec;
  unsigned int disTimer;
  unsigned char continuation;
}DISINFO;

typedef struct
{
  unsigned int blinkOnTimer;
  unsigned int blinkOffTimer;
  unsigned char blinkOnFlag;
  unsigned char blinkOffFlag;
  unsigned int ionOneSec;
  unsigned int ionTimer;
  unsigned char continuation;
}IONINFO;

typedef struct
{
  unsigned int totalOperatingHour;        //hour
  unsigned int uvLampCountHour;           //hour
  unsigned int ozoneLampCountHour;        //hour
  unsigned int filterCountHour;           //hour
  unsigned int totalOperatingMin;         //Minite
  unsigned int uvLampCountMin;            //Minite
  unsigned int ozoneLampCountMin;         //Minite
  unsigned int filterCountMin;           //Minite
  unsigned int modeFlag;
  unsigned int blinkOnTimer;
  unsigned int blinkOffTimer;
  unsigned char blinkOnFlag;
  unsigned char blinkOffFlag;
  unsigned int disOneSec;
  PLASMAINFO plasmaInfo;  
}SYSTEMINFO;


#define     UpgradeEEP           61110
#define     UpgradeEEP2          31110
#define     UpgradeEEPdata       0xa55a

#ifdef  CHECK_OZONE_LIMIT
    #define     CheckRoomTempEEP       61130
    #define     CheckRoomTempEEP2      31130    
    #define     CheckOZLimitEEPData   0xa53a
#endif
    
/* Global define ------------------------------------------------------------*/
#define MAX_RX_BUFFER 50
#define SYSTEM_SIZE   sizeof(SYSTEMINFO)
#define ONESEC        1000
#define FIVESEC       5000
#define MAX_SIZE_PRINT 500
extern unsigned int g_keyFlag;

#ifdef  INCLUDE_BD_DEBUG
  #define HALF_SEC  500         // SJM 190703 0.5sec = ONESEC/2 = 500
#endif

extern SYSTEMINFO sysConfig;
extern PLASMAINFO plasmaInfo;
extern DISINFO disInfo;
extern IONINFO ionInfo;

extern RTC_TimeTypeDef RTC_TimeStructure;
extern RTC_InitTypeDef RTC_InitStructure;
extern RTC_DateTypeDef RTC_DateStructure;
extern RTC_TimeTypeDef  RTC_TimeStampStructure;
extern RTC_DateTypeDef  RTC_TimeStampDateStructure;

/* Exported constants --------------------------------------------------------*/
#ifdef ENGLISH_VOICE
  //======================================================================================================================
  // Voice Track(��������� Ʈ����ȣ)
  //======================================================================================================================
  #define VOICE_POWERON_START                 0x10		
  #define VOICE_POWERON_END                   0x2a		

  #define VOICE_STERILIZATION_START_START     0x2b           
  #define VOICE_STERILIZATION_START_END       0x3B           

  #define VOICE_STERILIZATION_STOP_START      0x3C           
  #define VOICE_STERILIZATION_STOP_END        0x4E           

  #define VOICE_PREPARE_START                 0x4F           
  #define VOICE_PREPARE_END                   0x79   

  #define VOICE_ION_START_START               0x7A           
  #define VOICE_ION_START_END                 0x8B

  #define VOICE_PLASMA_START_START            0x8C           
  #define VOICE_PLASMA_START_END              0x9E

  #define VOICE_PIR_DETECT_START              0x9F           
  #define VOICE_PIR_DETECT_END                0xAD

  #define VOICE_POWER_OFF_START               0xAE           
  #define VOICE_POWER_OFF_END                 0xBB

  #define VOICE_KEY_START                     0xBC          
  #define VOICE_KEY_END                       0xC0

  #define VOICE_ION_STOP_START                0xC1          
  #define VOICE_ION_STOP_END                  0xD7

  #define VOICE_PLASMA_STOP_START             0xD8        
  #define VOICE_PLASMA_STOP_END               0xEC

  #define VOICE_DESTRUCTION_START_START       0xED       
  #define VOICE_DESTRUCTION_START_END         0x102

  #define VOICE_DESTRUCTION_ERROR_START       0x103
  #define VOICE_DESTRUCTION_ERROR_END         0x107

  #define VOICE_DESTRUCTION_STOP_START        0x108
  #define VOICE_DESTRUCTION_STOP_END          0x11E

  #define VOICE_OZONE_TIME_SET_START          0x11F
  #define VOICE_OZONE_TIME_SET_END            0x134

  #define VOICE_OZONE_DETECT_START            0x135
  #define VOICE_OZONE_DETECT_END              0x158

  //======================================================================================================================
  // Voice Track Delay(��������� �����ð�)
  //======================================================================================================================
  #define DELAY_POWERON                       3293        
  #define DELAY_STER_START                    2042        
  #define DELAY_STER_STOP                     2364
  #define DELAY_PREPARE                       5258
  #define DELAY_ION_START                     2164
  #define DELAY_PLASMA_START                  2350
  #define DELAY_PIR_DETECT                    1764
  #define DELAY_POWER_OFF                     1654
  #define DELAY_KEY                           523
  #define DELAY_ION_STOP                      2786
  #define DELAY_PLASMA_STOP                   2582
  #define DELAY_DESTRUCTION_START             2743
  #define DELAY_DESTRUCTION_ERROR             523
  #define DELAY_DESTRUCTION_STOP              2759
  #define DELAY_OZONE_TIME_SET                2687
  #define DELAY_OZONE_DETECT                  4471
#else // KOREAN_VOICE
  //======================================================================================================================
  // Voice Track(��������� Ʈ����ȣ)
  //======================================================================================================================
  #define VOICE_POWERON_START                 0x10		
  #define VOICE_POWERON_END                   0x2D		

  #define VOICE_STERILIZATION_START_START     0x2E           
  #define VOICE_STERILIZATION_START_END       0x3C           

  #define VOICE_STERILIZATION_STOP_START      0x3D           
  #define VOICE_STERILIZATION_STOP_END        0x4B           

  #define VOICE_PREPARE_START                 0x4C           
  #define VOICE_PREPARE_END                   0x6F   

  #define VOICE_ION_START_START               0x70           
  #define VOICE_ION_START_END                 0x7E

  #define VOICE_PLASMA_START_START            0x7F           
  #define VOICE_PLASMA_START_END              0x8E

  #define VOICE_PIR_DETECT_START              0x8F           
  #define VOICE_PIR_DETECT_END                0x9C

  #define VOICE_POWER_OFF_START               0x9D           
  #define VOICE_POWER_OFF_END                 0xAA

  #define VOICE_KEY_START                     0xAB          
  #define VOICE_KEY_END                       0xAF

  #define VOICE_ION_STOP_START                0xB0          
  #define VOICE_ION_STOP_END                  0xBD

  #define VOICE_PLASMA_STOP_START             0xBE        
  #define VOICE_PLASMA_STOP_END               0xCD

  #define VOICE_DESTRUCTION_START_START       0xCE       
  #define VOICE_DESTRUCTION_START_END         0xDC

  #define VOICE_DESTRUCTION_ERROR_START       0xDD
  #define VOICE_DESTRUCTION_ERROR_END         0xEA

  #define VOICE_DESTRUCTION_STOP_START        0xEB
  #define VOICE_DESTRUCTION_STOP_END          0xF9

  #define VOICE_OZONE_TIME_SET_START          0xFA
  #define VOICE_OZONE_TIME_SET_END            0x10B

  #define VOICE_OZONE_DETECT_START            0x10C
  #define VOICE_OZONE_DETECT_END              0x12E

  //======================================================================================================================
  // Voice Track Delay(��������� �����ð�)
  //======================================================================================================================
  #define DELAY_POWERON                       3643        
  #define DELAY_STER_START                    1840        
  #define DELAY_STER_STOP                     1840
  #define DELAY_PREPARE                       4443
  #define DELAY_ION_START                     1837
  #define DELAY_PLASMA_START                  1881
  #define DELAY_PIR_DETECT                    1689
  #define DELAY_POWER_OFF                     1654
  #define DELAY_KEY                           523
  #define DELAY_ION_STOP                      1734
  #define DELAY_PLASMA_STOP                   1964
  #define DELAY_DESTRUCTION_START             1769
  #define DELAY_DESTRUCTION_ERROR             1710
  #define DELAY_DESTRUCTION_STOP              1779
  #define DELAY_OZONE_TIME_SET                2136
  #define DELAY_OZONE_DETECT                  5000
#endif // ENGLISH_VOICE
//======================================================================================================================
// Voice Switch
//======================================================================================================================
#define SWITCH_POWER_ON                     1
#define SWITCH_STERILIZATION_START          2
#define SWITCH_STERILIZATION_STOP           3
#define SWTICH_PREPARE                      4
#define SWITCH_ION_START                    5
#define SWITCH_PLASMA_START                 6
#define SWITCH_PIR_DETECT                   7
#define SWITCH_POWER_OFF                    8
#define SWITCH_KEY                          9
#define SWITCH_ION_STOP                     10
#define SWITCH_PLASMA_STOP                  11
#define SWITCH_DESTRUCTION_START            12
#define SWITCH_DESTRUCTION_ERROR            13
#define SWITCH_DESTRUCTION_STOP             14
#define SWITCH_OZONE_TIME_SET               15
#define SWITCH_OZONE_DETECT                 16

/* Exported macro ------------------------------------------------------------*/
#define VOICE_PLAY(track)                   \
        do                                  \
        {                                   \
            ISD1760_setPlay(                \
                ##track##_START,            \
                ##track##_END,              \
                15);                        \
        } while(0);                         \


#define VOICE_OFF()                         \
        do                                  \
        {                                   \
        } while(0);
/* Exported functions ------------------------------------------------------- */

void TimingDelay_Decrement(void);
uint32_t sEE_TIMEOUT_UserCallback(void);
void Delay(__IO uint32_t nTime);
extern void voicePortInit();
#endif /* __MAIN_H */

/******************* (C) COPYRIGHT 2011 HealthWell *****END OF FILE****/
