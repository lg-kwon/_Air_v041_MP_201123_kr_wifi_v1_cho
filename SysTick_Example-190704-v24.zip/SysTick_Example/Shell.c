
#include "Shell.h"
#include "eeprom.h"

int fputc(int ch, FILE *f)
{
  /* Place your implementation of fputc here */
  /* e.g. write a character to the USART */
  USART_SendData(USART3, (uint8_t) ch);

  /* Loop until the end of transmission */
  while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET)
  {}

  return ch;
}

unsigned int getDigit(char digit)
{
    int value=0;
    if (digit>=0x30 && digit<=0x39) {
        value = digit-0x30;
    }
    else {
        digit &= 0xdf;
        if ( digit >= 'A' && digit <= 'F') {
            value = digit-'A'+10;
        }
    }
    return value&0xf;
}

int CheckValue(char *str)
{
    unsigned int value=0;
    int length,i;
    char *pdigit;
    if (strncmp(str,"0x",2)==0) {
        pdigit = &str[2];
        length = strlen(pdigit);
        
        value = 0;
        for (i=1;i<=length;i++) {
            value += getDigit(*pdigit++)<<((length-i)*4);
        }
    }
    else {
        length = strlen(str);
        value = atoi(str);
    }
    return value;
}

#define VOICE_CARE_STOP_START                 0x10		 // ġ�� ���� ���� ���ư���.
#define VOICE_CARE_STOP_END                   0x2D		 // ġ�� ���� ���� ���ư���.

extern unsigned int m_count;
extern unsigned int m_remoteState;
#ifdef  SJM_DEBUG
extern void voicePlay2(unsigned int voice);     // SJM 190617 for test
extern void readRemote();
extern unsigned char pirPort1, pirPort2;
extern double dOzoneSensoredValue;
extern unsigned int g_RemoteOzoneSensorValue;
extern int g_voicePortDelay;
extern unsigned int voicePlayFlag;
extern unsigned int currentState, isFirstEntrance;
#endif

void command_exec()
{
    char *opcode=pcommand[0];
    int value, value2;    
#ifdef  SJM_DEBUG
    unsigned int endAddr, delay;
#endif
    volatile unsigned int flashVal, reVal;
    
    if (strcmp(opcode,"help")==0) {
		printf("hello, Uart Shell Program!! \r\n");
    }
    
    if (strcmp(opcode,"eetest")==0) {	
      printf("eeprom test\r\n");
      value = CheckValue(pcommand[1]);
      value2 = CheckValue(pcommand[2]);

      systemWrite();
      systemRead();
    }
    if (strcmp(opcode,"chgState")==0) {
      value = CheckValue(pcommand[1]);
      if ((value<=0)||(value>LAST_STATE))
        printf("\r\n[ Usage ] chgState N (N=1~%d)\r\n", value);
      else
        changeState(value);
    }
    else if (strcmp(opcode,"shState")==0) {
      printf("\r\n[ Current State = %d, entrance = %d ]", currentState, isFirstEntrance);
    }
    
    if (strcmp(opcode,"relay")==0) {	
      value = CheckValue(pcommand[1]);
      value2 = CheckValue(pcommand[2]);
      relayControl(value, value2);
    }

//========= LED Test ==============================    
    if (strcmp(opcode,"ledtest")==0) {	
      printf("ledTest!\r\n");
      ledTest();
    }    
    if (strcmp(opcode,"led")==0) {	
      printf("led!\r\n");
      value = CheckValue(pcommand[1]);
      value2 = CheckValue(pcommand[2]);
      ledControl(value, value2);
    }
    if (strcmp(opcode,"ledcom")==0) {	
      printf("ledcom!\r\n");
      value = CheckValue(pcommand[1]);
      value2 = CheckValue(pcommand[2]);
      ledComControl(value, value2);
    }
    if(strcmp(opcode, "ledon") == 0)
    {
      printf("led all On\r\n");  
      G1_SF = 0xff;
      G2_SF = 0xff;
      G3_SF = 0xff;
      G4_SF = 0xff;
      G5_SF = 0xff;
    }
    if(strcmp(opcode, "ledoff") == 0)
    {
      printf("led all Off\r\n");  
      G1_SF = 0;
      G2_SF = 0;
      G3_SF = 0;
      G4_SF = 0;
      G5_SF = 0;
    }
    if (strcmp(opcode,"seg")==0) {	
      printf("seg!\r\n");
      value = CheckValue(pcommand[1]);
      segmentControl(value);
    }
#ifdef  SJM_DEBUG
    if (strcmp(opcode,"segA")==0) {	// SJM 190617 for test
      printf("segAlpha %s\r\n",pcommand[1]);
      segmentAlphaControl(pcommand[1][0],pcommand[1][1]);
    }
#endif
    
//========= Voice Test ==============================    
    if (strcmp(opcode,"vtest")==0) {	
      printf("voice Play!\r\n");
      VOICE_PLAY(VOICE_CARE_STOP);
    }
    if (strcmp(opcode,"vvtest")==0) {
      printf("spi\r\n");
      ISD1760_powerUp();
      Delay(10);
      value = ISD1760_readStatus();
      printf("value : 0x%x", value);
    }
    if (strcmp(opcode,"stop")==0) {
      printf("spi\r\n");
      ISD1760_stop();
      Delay(10);
      value = ISD1760_readStatus();
      printf("value : 0x%x", value);
    }
#ifdef  SJM_DEBUG
    if (strcmp(opcode,"vp")==0) {          // SJM 190621 for voice setting
      value = CheckValue(pcommand[1]);
      if ((value <= 0)|| (value > 20))
        printf("[Usage : vp voice# start end delay ]\r\n");
      else {
        value2 = CheckValue(pcommand[2]);
        endAddr = CheckValue(pcommand[3]);
        delay = CheckValue(pcommand[4]);
        printf("VoicePlay %d %d[0x%x] %d[0x%x] %d\r\n", value, value2, value2, endAddr, endAddr, delay);
        
        g_voicePortDelay = delay;
        printf("g_voicePortDelay : %d\r\n", g_voicePortDelay);
        Delay(10);
        voicePlayFlag = TRUE;
        //VOICE_PLAY(VOICE_OZONE_DETECT);
        ISD1760_setPlay(value2, endAddr, 15);
      }
    }
    if (strcmp(opcode,"vplay")==0) {      // SJM 190617 for test
      value = CheckValue(pcommand[1]);
      printf("voice Play=%d!\r\n",value);
      voicePlay2(value);
    }

    else if (strcmp(opcode,"chkPir")==0) {      // SJM 190617 for test
      printf("pirPort1 = %d , pirPort2 = %d\r\n",pirPort1, pirPort2);
    }
    else if (strcmp(opcode,"testPir")==0) {      // SJM 190617 for test
      value = getPirPort1();
      value2 = getPirPort2();
      printf("pirPort1 = %d , pirPort2 = %d, getPort1 = %d, getPort2 = %d\r\n",pirPort1, pirPort2, value, value2);
    }
    else if (strcmp(opcode,"chkOzone")==0) {      // SJM 190617 for test
      printf("Local = %f , Remote = %d\r\n",dOzoneSensoredValue, g_RemoteOzoneSensorValue);
    }
    else if (strcmp(opcode,"testOzone")==0) {      // SJM 190617 for test
      readRemote();
      printf("Local = %f , Remote = %d\r\n",dOzoneSensoredValue, g_RemoteOzoneSensorValue);
    }
#endif
    
    if(strcmp(opcode, "state") == 0){
      printf("state : %d, count : %d\r\n", m_remoteState, m_count); 
      m_remoteState = 0;
      m_count = 0;
    }
    if(strcmp(opcode, "ptest") == 0)
    {
      printf("print On\r\n");  
      printfTest = TRUE;
    }

    if(strcmp(opcode, "1690") == 0)
    {
      printf("setting!\r\n");
      settingMainMenu();  
    }
    if(strcmp(opcode, "time") == 0)
    {
      printf("time!\r\n");
      RTC_TimeShow();  
    }
    if(strcmp(opcode, "copytime") == 0)
    {
      copyTime();  
    }
    if(strcmp(opcode, "date") == 0)
    {
      printf("date!\r\n");
      RTC_DateShow();  
    }
    if (strcmp(opcode,"settime")==0) {	
      printf("setting Time\r\n");
      RTC_TimeRegulate();
    }
    
    if(strcmp(opcode, "uv") == 0)
    {
      value = CheckValue(pcommand[1]);
      printf("uvlamp : %d\r\n", value);
      sysConfig.uvLampCountHour = value;
      systemWrite();
    }
    
    if(strcmp(opcode, "filter") == 0)
    {
      value = CheckValue(pcommand[1]);
      printf("filter : %d\r\n", value);
      sysConfig.filterCountHour = value;
      systemWrite();
    }
    if(strcmp(opcode, "ozone") == 0)
    {
      value = CheckValue(pcommand[1]);
      printf("filter : %d\r\n", value);
      sysConfig.ozoneLampCountHour = value;
      systemWrite();
    }
    if(strcmp(opcode, "consume") == 0)
    {
      systemRead();
      
      printf("ozoneLamp : %d:%d\r\n", sysConfig.ozoneLampCountHour, sysConfig.ozoneLampCountMin);
      printf("uvLamp : %d:%d\r\n", sysConfig.uvLampCountHour, sysConfig.uvLampCountMin);
      printf("filter : %d:%d\r\n", sysConfig.filterCountHour, sysConfig.filterCountMin); 
    }
    
    if(strcmp(opcode, "usb") == 0)
    {
      UpgradeEEPWrite(UpgradeEEPdata);
      NVIC_SystemReset();
    }
    
    if(strcmp(opcode, "oz") == 0)
    {
      if(getOzoneSensor() == TRUE)
      {
        printf("ozone detect!!\r\n");  
      }
      else
      {
        printf("ozone no detect!!\r\n");  
      }
    }
    
#ifdef  CHECK_OZONE_LIMIT
    if( strcmp(opcode, "readozflag") == 0)
    {
        uint16_t  bTemp = CheckRoomTempEEPRead();
        
        printf("\r\n Ignition Flag Value[%c]", bTemp);
    }

    if( strcmp(opcode, "writeozflag") == 0)
    {
        value = CheckValue(pcommand[1]);
      
        CheckRoomTempEEPWrite(value);
        
        printf("\r\n Ignition Flag Value[%c]", CheckRoomTempEEPRead());
    }
#endif
    
}

void command_analysis()
{
    u8   i;
    u8   space_find = 1;
    char *str;
    
    para_idx=0;
    str = &command_str[0];
    for (i=0;i<COMMAND_MAX;i++) pcommand[i] = 0;
    
    while(*str)
    {
        if (*str != ' ') {
            if (space_find) {
                pcommand[para_idx++] = str;
                space_find = 0;
                if (para_idx>COMMAND_MAX) break;
            }
        }
        else {
            if (space_find==0) {
                *str = 0;
            }
            space_find = 1;
        }
        str++;
    }
    if (para_idx>0) {
        command_exec();
    }
}

void GetUARTData()
{
    char ch;
	
    if (rx_head!=rx_tail) {
        ch = rx_buffer[rx_tail];
        if (++rx_tail>=MAX_RX_BUFFER) rx_tail=0;
        if (ch==0xd || ch==0xa) {
            if (ch==0xd) {
                command_str[command_str_idx] = 0;
                if (command_str_idx!=0) {
                    printf("\r\n");
                    command_analysis();
                } 
                command_str_idx = 0;
                printf("\r\n=>");
            }
        }
        else {
            if (ch==0x8) {
                if (command_str_idx>0) {
                    --command_str_idx;
                    command_str[command_str_idx] = 0;
                    printf("%c %c",ch,ch);
                }  
            }
            else {
                if (ch == 9) ch=0x20;
                if (command_str_idx<COMMAND_STR_MAX-2) {
                    if (ch==0x20 || (ch>='0' && ch <='9') || (ch>='a' && ch <='z')
                        || (ch>='A' && ch <='Z') || ch == '?') {
							printf("%c",ch);
							command_str[command_str_idx++] = ch;
							command_str[command_str_idx] = 0;
						}
                }
            }
        }
    }
}