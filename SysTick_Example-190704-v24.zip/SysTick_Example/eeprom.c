#include "eeprom.h"
#include "24LC512.h"

#define sEE_WRITE_ADDRESS1        0x200
#define sEE_READ_ADDRESS1         0x200

void UpgradeEEPWrite(uint16_t data)
{
  uint8_t   buf[2];

  Delay(10);
  
  printf("data = %x \r\n", data);
  buf[0] = (data & 0xff00) >> 8;
  buf[1] = (data & 0x00ff);

  sEE_WriteBuffer(buf, UpgradeEEP, 2);
  sEE_WaitEepromStandbyState();
  Delay(100);
  sEE_WriteBuffer(buf, UpgradeEEP2, 2);
  sEE_WaitEepromStandbyState();
}

void systemWrite()
{
  unsigned char DataBuffer[SYSTEM_SIZE]; 
  
  sysConfig.plasmaInfo = plasmaInfo;
  
  printf("SYSTEM_SIZE : %d\r\n", SYSTEM_SIZE);
  memcpy(DataBuffer, &sysConfig, SYSTEM_SIZE);
  Delay(100);

  sEE_WriteBuffer(DataBuffer, sEE_WRITE_ADDRESS1, SYSTEM_SIZE);
  Delay(100);
  /* Wait for EEPROM standby state */
  sEE_WaitEepromStandbyState();
  Delay(100);
  
  printf("eeWrite!!\r\n");
}

void systemRead()
{
  unsigned char buffer[SYSTEM_SIZE];
  unsigned short NumDataRead = SYSTEM_SIZE;

  printf("System size : %d\r\n", NumDataRead);
  
  sEE_WaitEepromStandbyState();
  sEE_ReadBuffer(buffer, sEE_READ_ADDRESS1, &NumDataRead);
  
  Delay(100);
    
  memcpy(&sysConfig, buffer, SYSTEM_SIZE);

  plasmaInfo = sysConfig.plasmaInfo;
  
  /*
  for(int i = 0; i < SYSTEM_SIZE; i++)
  {
    printf("system[%d] : %x\r\n", i, buffer[i]);  
  }*/
  
  
  printf("eeread!!!\r\n");
}

#ifdef  CHECK_OZONE_LIMIT
uint16_t CheckRoomTempEEPRead(void)
{
  uint8_t   buf[2];
  unsigned short NumDataRead =2;
  uint16_t  CheckTemp;
  
  sEE_WaitEepromStandbyState();
  sEE_ReadBuffer(buf, CheckRoomTempEEP, &NumDataRead);
  Delay(10);
  
  CheckTemp = ((buf[0] & 0x00ff) << 8) + buf[1];

  return CheckTemp;
}

void CheckRoomTempEEPWrite(uint16_t data)
{
  uint8_t   buf[2];
//  uint16_t  cnt;

  Delay(10);
  printf("data = %x \r\n", data);

  buf[0] = (data & 0xff00) >> 8;
  buf[1] = (data & 0x00ff);

  sEE_WriteBuffer(buf, CheckRoomTempEEP, 2);
  sEE_WaitEepromStandbyState();
  Delay(100);
  sEE_WriteBuffer(buf, CheckRoomTempEEP2, 2);
  sEE_WaitEepromStandbyState();
}
#endif