/**
  * 0.5v - �ö�� ��忡�� ������ ������ ���� ��.(���� ��忡 �°�)
  *        ���� ���� �߰�
  * 0.6v - �ö�� ��忡�� ��ü���� ���� ����.
  *        ��ü ���� �߿��� ���� ���� �۵� ����.
  *        �ö�� ��忡�� ���� ���� ���� ����(0~3 -> 0~2)
  * 0.7v - ����� ��忡�� UV Lamp�� ���۽�Ŵ
  *        �ö�� ��忡�� �⺻ ���⸦ 1�� ����, ���� ����(0~2 -> 1~3)
  * 0.8v - �ö�� ��� ���� �� ���� ��ư�� ������ ���� ���Ⱑ ǥ�� ��.
  *        �Ҹ�ǰ ��ü Warningǥ�� �� Ȯ�� ��ư�� ������ Main���� �Ѿ� ��.
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/** @addtogroup STM32F4xx_StdPeriph_Examples
  * @{
  */

/** @addtogroup SysTick_Example
  * @{
  */ 

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
unsigned int testLedBlink = FALSE;
unsigned char rx_buffer[MAX_RX_BUFFER];
unsigned char rx_head;
unsigned char rx_tail;
unsigned char setRTCFlag;
unsigned int m_remoteState;
extern unsigned char pBuf[];
extern unsigned int pPointer;
unsigned int oldPpointer;
unsigned char printfTest;
unsigned int segBlinkOnTime;

unsigned int currentState, isFirstEntrance, isReadyEntrance;
unsigned char pidDetect;
unsigned int oneSecFlag;
unsigned int g_remoteFlag;

SYSTEMINFO sysConfig;
PLASMAINFO plasmaInfo;
DISINFO disInfo;
IONINFO ionInfo;

GPIO_InitTypeDef GPIO_InitStructure;
static __IO uint32_t TimingDelay;
  
/* Private function prototypes -----------------------------------------------*/
void Delay(__IO uint32_t nTime);

/* Private functions ---------------------------------------------------------*/
extern void GetUARTData();
extern void handler();
/**
  * @brief   Main program
  * @param  None
  * @retval None
  */

int main(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure;
  
  /* Enable the GPIO_LED Clock */
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
  
  
  /* Configure the GPIO_LED pin */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);

  if (SysTick_Config(SystemCoreClock / 1000))
  { 
    /* Capture error */ 
    while (1);
  }

  TIM_Config();
  remoteTimerInit();
  remoteInit();
  Uart_init();
  pirInit();
  sEE_Init();    //24LC512 Init
  relayControlInit();   //relay port Init
  keyPortInit();
  ledPortInit();
  ISD1760_init();
  voicePortInit(); //voice Port init

  ozoneSensorInit();
  ADC_SoftwareStartConv(ADC1);
  
  GPIOB->BSRRL = GPIO_Pin_8;
  Delay(10);
  
  rtc_check();
  rtc_init();
  
  printfTest = FALSE;
  printf("\r\n  Wall Type      \r\n");
  printf("\r\n   Ver 0.7       \r\n");
  printf("\r\n  Author : SBKIM \r\n");
  
  
  currentState = STATE_POWER_OFF;
  isFirstEntrance = TRUE;

  //system loading
  systemRead();
  
  while (1)
  {
    GetUARTData();
    handler();
    if(testLedBlink == TRUE)
    {
      testLedBlink = FALSE;
      GPIOB->ODR ^= GPIO_Pin_8;
      //GPIOA->ODR ^= GPIO_Pin_14;
    }
#ifdef  INCLUDE_BD_DEBUG
    if (currentState != STATE_BD_DEBUG) {
#endif
    
    if(pidDetect == TRUE)     // SJM 190704 ???
    {
      pidDetect = FALSE;
    }
    
    //���� ����.
    if(currentState == STATE_POWER_OFF || currentState == STATE_READY_STER ||
       currentState == STATE_READY_ION || currentState == STATE_READY_DIS )
    {
      //1�ʸ���.
      if(oneSecFlag == TRUE)
      {
          oneSecFlag = FALSE;
          RTC_GetTime(RTC_Format_BIN, &RTC_TimeStructure);
          (void)RTC->DR;
          if(plasmaInfo.rsvOn == TRUE)
          {
            if(RTC_TimeStructure.RTC_Hours == plasmaInfo.rsvTime && 
               RTC_TimeStructure.RTC_Minutes == 0 && 
               RTC_TimeStructure.RTC_Seconds == 0)
            {
              currentState = STATE_STER;
              isFirstEntrance = TRUE;
              plasmaInfo.Mode = PLASMA_MODE_RESERVE;
            }
          }
      }
    }
#ifdef  INCLUDE_BD_DEBUG
    }
#endif

    if(pPointer != oldPpointer)
    {
      printf("%c", pBuf[oldPpointer]);
      if(++oldPpointer > MAX_SIZE_PRINT)
        oldPpointer = 0;
    }
  }
}

/**
  * @brief  Inserts a delay time.
  * @param  nTime: specifies the delay time length, in milliseconds.
  * @retval None
  */
void Delay(__IO uint32_t nTime)
{ 
  TimingDelay = nTime;

  while(TimingDelay != 0);
}

/**
  * @brief  Decrements the TimingDelay variable.
  * @param  None
  * @retval None
  */
void TimingDelay_Decrement(void)
{
  if (TimingDelay != 0x00)
  { 
    TimingDelay--;
  }
}

#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}

uint32_t sEE_TIMEOUT_UserCallback(void)
{
  
  printf("eeprom error11\r\n");
  
  /* Block communication and all processes */
  /*while (1)
  {   
  }  */
  return 0;
}

#endif

/**
  * @}
  */ 

/**
  * @}
  */ 

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
