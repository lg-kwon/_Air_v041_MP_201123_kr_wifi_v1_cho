#include "handler.h"

extern void ledAllOn();
extern void reduceOzoneLevel();
extern void normalPlasmaSter();

//unsigned char exMin;    SJM 190711 it is assigned but never used anywhere...???
unsigned int segmentCycle=1;
unsigned int g_RemoteOzoneSensorValue;

//unsigned int  g_countPlamsaButtonPressed;   SJM 190711 it is never used anywhere...???
extern unsigned int g_extOzoneSenseFlag;
extern unsigned char halfSecFlag;

RTC_TimeTypeDef curTime;
unsigned int tempHour, tempMin, tempRsvTime, tempRsvFlag;
unsigned char ledStatus = 0;
unsigned char continueOperation = FALSE;    // SJM 190724 unify continue operation
unsigned short ozoneRangeOver = 0;
//unsigned int ledStep, opMode;
#ifdef  INCLUDE_RETURN_TO_CONTINUOUS_MODE
unsigned char returnToContinuousOperation=FALSE;
unsigned char prevOperation=DEFAULT_STATE;
#endif
#ifdef  INCLUDE_STRENGTHEN_OZONE
  unsigned int setTime, operatedTime;
#endif

void changeState(unsigned char state, unsigned char write)
{
  sysConfig.prevState = currentState;
  // SJM 191119 add safety transion when 'state' is abnormal.
  if ((state<STATE_READY_STER)||(state>LAST_STATE)) {
    printf("\r\n [Abnormal Call : curState = %d, destState = %d\r\n", currentState, state);
    currentState = DEFAULT_STATE;
  }
  else
    currentState = state;
  isFirstEntrance = TRUE;
  printf("\r\n>> switch to State %d\r\n", state);
  if (write) systemWrite();
}

void  checkStart()
{
  static unsigned char alreadyChecked = FALSE;
  
  if (alreadyChecked==FALSE) {
    alreadyChecked = TRUE;
    if (consumableCheck()) {     // SJM 200528 add
      changeState(STATE_CONSUMABLE_WARNING,FALSE);
    }
  }
  else if(g_remoteFlag & (BUTTON_RIGHT | BUTTON_RIGHT_LONG)) {
    g_remoteFlag = 0;
//    isFirstEntrance = TRUE;
    switch (currentState) {
      case STATE_READY_STER :
        if(plasmaInfo.pidOn == TRUE)  changeState(STATE_PREPARE,FALSE);
        else                          changeState(STATE_STER,FALSE);
//        plasmaInfo.Mode = PLASMA_MODE_START;    SJM 190724 removed. 'normal start' case
        alreadyChecked = FALSE;
        break;
      case STATE_READY_DIS :
        changeState(STATE_DIS,FALSE);
        alreadyChecked = FALSE;
        break;
      case STATE_READY_ION :
        changeState(STATE_ION,FALSE);
        alreadyChecked = FALSE;
        break;
      default :
        voicePlay(SWITCH_KEY, DELAY_KEY); Delay(DELAY_KEY);
        voicePlay(SWITCH_KEY, DELAY_KEY); Delay(DELAY_KEY);
        printf("\r\n[Error State!! currentState = %d]\r\n", currentState);
        break;
    }
  }
}

void checkPowerOff(unsigned int nextState)
{
  if(g_remoteFlag & (BUTTON_POWER | BUTTON_POWER_LONG)) {
    g_remoteFlag = 0;
    if (nextState == STATE_POWER_OFF) {
      voicePlay(SWITCH_POWER_OFF, DELAY_POWER_OFF);
      Delay(DELAY_POWER_OFF);
    }
    changeState(nextState,TRUE);
  }
}

void checkBaseMode(unsigned char skip)
{
  //Ion Mode
  if(g_remoteFlag & (BUTTON_ANION | BUTTON_ANION_LONG)) {
    g_remoteFlag = 0;
    changeState(STATE_READY_ION,FALSE);
  }  
  //��� ���
  if(g_remoteFlag & (BUTTON_DISINFECT | BUTTON_DISINFECT_LONG)) {
    g_remoteFlag = 0;
    changeState(STATE_READY_DIS,FALSE);
  }
  if (skip) return;       // SJM 200422 different control for setup mode
                          //            without clearing "g_remoteFlag = 0"
  //�ö�� ���
  if(g_remoteFlag & (BUTTON_PLASMA | BUTTON_PLASMA_LONG)) {
    g_remoteFlag = 0;
    changeState(STATE_READY_STER,FALSE);
  }
}

void handlePowerOff()
{
  if(isFirstEntrance == TRUE) {
    printf("\r\n [ STATE_POWER_OFF : %d ]", currentState);
    isFirstEntrance = FALSE;
    RTC_TimeShow();         // SJM 200506 for Debug
    control_relayAllOff();
    ledAllOff();
//    segmentOff();       SJM 190715 included in ledAllOff()
    systemWrite();
//    pidLEDOnFlag = FALSE;     SJM 190711 always assigned to 'FALSE' & never used
    pidDetect = FALSE;
//    if(plasmaInfo.rsvOn == TRUE)
//      ledControl(LED_RESERVE_ON, LED_ON);
#ifdef  AUTO_POWER_ON
    currentState = STATE_INIT;  
    isFirstEntrance = TRUE;
#endif
  }
  
  if (halfSecFlag) {
    halfSecFlag = FALSE;
    if (plasmaInfo.rsvOn) {
      ledStatus ^= 1;
      ledControl(LED_RESERVE_ON, ledStatus);
    }
  }

  checkPowerOff(STATE_INIT);
}

void handleConsumableWarning()
{
  static unsigned int warningType[WARNING_NUMBER];
  static unsigned int warningNum;
  static unsigned int warning;
  static unsigned int warningCount;
  static unsigned char resetPreFlag;
  static unsigned char checkWarning;
  
  if(isFirstEntrance == TRUE) {
    printf("\r\n [ STATE_CONSUMABLE_WARNING : %d ]", currentState);
    isFirstEntrance = FALSE;
    RTC_TimeShow();         // SJM 200506 for Debug
    //LED control
    control_consumableCheckLed();
    //FND control
//    segmentControl(0);
    segmentAlphaControl('E','-');
    //warning check
    resetPreFlag = FALSE;
    checkWarning = TRUE;
    voicePlay(SWITCH_CONSUMABLE_CHECK, DELAY_CONSUMABLE_CHECK);
    Delay(DELAY_CONSUMABLE_CHECK);
    printf("Consumable Warning mode\r\n");
  }
  
  //blink
  {
    if (checkWarning) {     // update Warning Table
      checkWarning = FALSE;
      warning = consumableCheck();
      if (warning==0) {
        changeState(STATE_INIT,TRUE);
        return;
      }
      for(int i = warningNum = 0 ; i < WARNING_NUMBER; i++) {
        printf("compare[%d] 0x%x & 0x%x\r\n", i, warning, (1 << i));
        if(warning & (1 << i)) {
//        warningType[i] = (1 << i);
          warningType[warningNum++] = (1 << i);
//        warningNum++;
          printf("warning : 0x%x\r\n", (1 << i));
        }
      }
      warningCount = 0;
      printf("warningType[%d] : 0x%x\r\n", warningNum, warning);
    }
    if(sysConfig.blinkOffFlag == TRUE) {
      sysConfig.blinkOffFlag = FALSE;
      if(warningType[warningCount] & WARNING_OZONE_LAMP)    segmentAlphaControl('E','O');
      else if(warningType[warningCount] & WARNING_UV_LAMP)  segmentAlphaControl('E','U');
      else if(warningType[warningCount] & WARNING_RCI_CELL) segmentAlphaControl('E','A');
      else if(warningType[warningCount] & WARNING_FILTER)   segmentAlphaControl('E','F');
      if(++warningCount >= warningNum)    warningCount = 0;
    }
    if(sysConfig.blinkOnFlag == TRUE) {
      segmentOff();
      sysConfig.blinkOnFlag = FALSE;
    }
  }
  
  //reset preKey
  if(g_remoteFlag & (REMOTE_UP_LONG_FLAG))
  {
    g_remoteFlag = 0;
#ifdef  INCLUDE_REMOTE_ACK
    voicePlay(SWITCH_KEY, DELAY_KEY);    
#endif
    resetPreFlag = TRUE;
    printf("preKey On!!\r\n");
  }
  
  //uvlamp reset
  if(g_remoteFlag & (REMOTE_WIND_LONG_FLAG)) {
    g_remoteFlag = 0;
    if(resetPreFlag == TRUE) {
#ifdef  INCLUDE_REMOTE_ACK
      voicePlay(SWITCH_KEY, DELAY_KEY);    
#endif
      resetPreFlag = FALSE;
      sysConfig.uvLampCountMin = 0;
      systemWrite();
      checkWarning = TRUE;
      printf("reset UV Lamp!!\r\n");
    }
  }
  //ozonelamp reset
  if(g_remoteFlag & (REMOTE_ION_LONG_FLAG)) {
    g_remoteFlag = 0;
    if(resetPreFlag == TRUE) {
#ifdef  INCLUDE_REMOTE_ACK
      voicePlay(SWITCH_KEY, DELAY_KEY);    
#endif
      resetPreFlag = FALSE;
      sysConfig.ozoneLampCountMin = 0;
      systemWrite();
      checkWarning = TRUE;
      printf("reset Ozone Lamp!!\r\n");
    }
  }
  //RCI cell reset
  if(g_remoteFlag & (REMOTE_PLASMA_LONG_FLAG)) {
    g_remoteFlag = 0;
    if(resetPreFlag == TRUE) {
#ifdef  INCLUDE_REMOTE_ACK
      voicePlay(SWITCH_KEY, DELAY_KEY);    
#endif
      resetPreFlag = FALSE;
      sysConfig.rciOperatingMin = 0;
      systemWrite();
      checkWarning = TRUE;
      printf("reset RCI Cell!!\r\n");
    }
  }
  //filter reset
  if(g_remoteFlag & (REMOTE_MENU_LONG_FLAG)) {
    g_remoteFlag = 0;
    if(resetPreFlag == TRUE) {
  #ifdef  INCLUDE_REMOTE_ACK
      voicePlay(SWITCH_KEY, DELAY_KEY);    
  #endif
      resetPreFlag = FALSE;
      sysConfig.filterCountMin = 0;
      systemWrite();
      checkWarning = TRUE;
      printf("filter reset!!\r\n");
    }
  }
#if 0
  if(g_remoteFlag & (REMOTE_DOWN_LONG_FLAG | REMOTE_DOWN_FLAG)) {
    g_remoteFlag = 0;
  #ifdef  INCLUDE_REMOTE_ACK
//    voicePlay(SWITCH_KEY, DELAY_KEY);    
  #endif    
    changeState(STATE_READY_DIS,TRUE);
  }
#else
  checkBaseMode(0);
#endif
//  checkPowerOff(STATE_INIT);
  checkPowerOff(STATE_POWER_OFF);   // SJM 190723 otherwise it can't be off!!!
}

void handleInit()
{
  if(isFirstEntrance == TRUE) {
    printf("\r\n [ STATE_INIT : %d ]", currentState);
    isFirstEntrance = FALSE;
    RTC_TimeShow();         // SJM 200506 for Debug
    //�ʱ� voice
    voicePlay(SWITCH_POWER_ON, DELAY_POWERON);
    //S/W ����
    segmentControl(SW_VERSION);
    //LED ����
    control_initLed();
    WhiteLed();
    //eeprom data loading.
    systemRead();
    pidDetect = FALSE;
/*   SJM 200508 move consumable check point 
    //�Ҹ�ǰ üũ.
    if (consumableCheck())
          changeState(STATE_CONSUMABLE_WARNING,FALSE);
    else
*/
    if ((sysConfig.prevState>0)&&(sysConfig.prevState<4))
          changeState(sysConfig.prevState,FALSE);
    else  changeState(DEFAULT_STATE,FALSE);
#if 0
    if(consumableCheck() > 0) {
      changeState(STATE_CONSUMABLE_WARNING,FALSE);
    }
    else {
      if(sysConfig.modeFlag == MODE_STER) {
        currentState = STATE_READY_STER;
//        plasmaInfo.modeSelect = SETTING_NONE;     SJM 190715 useless??
      }
      else if(sysConfig.modeFlag == MODE_DIS) {
        currentState = STATE_READY_DIS;
      }
      else if(sysConfig.modeFlag == MODE_ION) {
        currentState = STATE_READY_ION;
      }
      else {
    #ifndef  CHANGE_DEFAULAT_MODE
        currentState = STATE_READY_STER;
    #else
        currentState = STATE_READY_DIS;
    #endif        
      }
    }
    isFirstEntrance = TRUE;
#endif
  }
}

void handleReadyPlasmaSter()
{
  static unsigned char editMode = 0;  // 0=Time, 1=Intensity
  
  if(isFirstEntrance == TRUE) {
    printf("\r\n [ STATE_READY_STER : %d ]", currentState);
    isFirstEntrance = FALSE;
    RTC_TimeShow();         // SJM 200506 for Debug
#ifdef VOICE_FIRST
    voicePlay(SWITCH_PLASMA_MODE, DELAY_PLASMA_MODE);
    Delay(DELAY_PLASMA_MODE);
#endif
    prevOperation = STATE_READY_STER;   // SJM 200506 debugged for normal(manual) operation
    //led Font on
    control_ledFont();
    ledControl(LED_PLASMA_ON, LED_ON);
    //relay all off
    control_relayAllOff();
    // Default setting & LED display
    editMode = 0;
    plasmaInfo.pidOn = TRUE;
    plasmaInfo.pwr = 3;
#ifndef REDUCE_TIME_TO_TEST
    plasmaInfo.plasmaTimer = 30 * 60;
#else
    plasmaInfo.plasmaTimer = 30;
#endif
#ifdef  UNIFY_CONTINUE_OP
    continueOperation = FALSE;
#else
    plasmaInfo.continuation = FALSE;
#endif
    ledControl(LED_PID_ON, plasmaInfo.pidOn);
    ledControl(LED_RESERVE_ON, plasmaInfo.rsvOn);
#ifndef REDUCE_TIME_TO_TEST
    segmentControl(plasmaInfo.plasmaTimer/60);
#else
    segmentControl(plasmaInfo.plasmaTimer);
#endif

    if(plasmaInfo.rsvOn == TRUE) {
//      printf("select Mode : %d\r\n", plasmaInfo.modeSelect);  SJM 190715 useless??
      printf("select rsvOn : %d\r\n", plasmaInfo.rsvOn);
      printf("select rsvTime : %d\r\n", plasmaInfo.rsvTime);
//      plasmaInfo.modeSelect = SETTING_NONE;                   SJM 190715 useless??
    }
#ifndef VOICE_FIRST
    voicePlay(SWITCH_PLASMA_MODE, DELAY_PLASMA_MODE);
    Delay(DELAY_PLASMA_MODE);
#endif
  }

  if (halfSecFlag) {
    halfSecFlag = FALSE;
    ledStatus ^= 1;
    ledControl(LED_PID_ON, plasmaInfo.pidOn);
//    ledControl(LED_PID_FONT, plasmaInfo.pidOn);
    switch (editMode) {
      case 0 :  // Time Adjust
        switch (plasmaInfo.pwr) {
          case 1 :
            ledControl(LED_POWER_FONT, LED_ON);
            ledControl(LED_POWER_ON, LED_OFF);
            break;
          case 2 :
            ledControl(LED_POWER_FONT, LED_OFF);
            ledControl(LED_POWER_ON, LED_ON);
            break;
          case 3 :
            ledControl(LED_POWER_FONT, LED_ON);
            ledControl(LED_POWER_ON, LED_ON);
            break;
        }
        ledControl(LED_RESERVE_FONT, ledStatus);
#ifdef  UNIFY_CONTINUE_OP
        if (continueOperation)  segmentAlphaControl('O','n');
#else
        if (plasmaInfo.continuation)  segmentAlphaControl('O','n');
#endif
#ifndef REDUCE_TIME_TO_TEST
        else                          segmentControl(plasmaInfo.plasmaTimer/60);
#else
        else                          segmentControl(plasmaInfo.plasmaTimer);
#endif
        break;
      case 1 :  // Intensity Adjust
        ledControl(LED_POWER_FONT, ledStatus);
        ledControl(LED_POWER_ON, ledStatus);
        ledControl(LED_RESERVE_FONT, LED_OFF);
        segmentControl(plasmaInfo.pwr);
        break;
    }
  }

  //Power setting
  if(g_remoteFlag & (BUTTON_INTENSITY | BUTTON_INTENSITY)) {
    g_remoteFlag = 0;
    if (editMode==0) {
      editMode = 1;
      voicePlay(SWITCH_KEY, DELAY_KEY);
    }
    else {
      if(++plasmaInfo.pwr > 3)  plasmaInfo.pwr = 1;
    }
//    segmentControl(plasmaInfo.pwr);
//    plasmaInfo.modeSelect = SETTING_POWER;      SJM 190715 useless??
    printf("power setting\r\n");
  }
  //PID setting
  if(g_remoteFlag & (REMOTE_PLASMA_FLAG | REMOTE_PLASMA_LONG_FLAG)) {
    g_remoteFlag = 0;
    voicePlay(SWITCH_KEY, DELAY_KEY);
    plasmaInfo.pidOn ^= 1;
    // SJM 200508 PID & continueOperation are exclusive.
    if (plasmaInfo.pidOn) continueOperation = FALSE;
    ledControl(LED_PID_ON,plasmaInfo.pidOn);
  }
  //Time setting
  if (g_remoteFlag & ( BUTTON_TIME )) {
    g_remoteFlag = 0;
    editMode = 0;
    voicePlay(SWITCH_KEY, DELAY_KEY);
  }
  //Continuation Mode
  if (g_remoteFlag & ( BUTTON_TIME_LONG )) {
    g_remoteFlag = 0;
    editMode = 0;
#ifdef  UNIFY_CONTINUE_OP
    continueOperation = TRUE;
    // SJM 200508 PID & continueOperation are exclusive.
    plasmaInfo.pidOn = FALSE;
    ledControl(LED_PID_ON,plasmaInfo.pidOn);
#else
    plasmaInfo.continuation = TRUE;
#endif
    voicePlay(SWITCH_KEY, DELAY_KEY);
  }
  //up Key
  if(g_remoteFlag & (REMOTE_UP_FLAG | REMOTE_UP_LONG_FLAG)) {
    g_remoteFlag = 0;
    if (editMode) {   // Intensity Adjust
      if(++plasmaInfo.pwr > 3)  plasmaInfo.pwr = 1;
    }
    else {            // Time Adjust
#ifdef  UNIFY_CONTINUE_OP
      continueOperation = FALSE;
#else
      plasmaInfo.continuation = FALSE;
#endif
#ifndef REDUCE_TIME_TO_TEST
      if(plasmaInfo.plasmaTimer < 60 * 60)
        plasmaInfo.plasmaTimer += 5 * 60;
#else
      if(plasmaInfo.plasmaTimer < 60)
        plasmaInfo.plasmaTimer += 5;
#endif
      voicePlay(SWITCH_KEY, DELAY_KEY);
//    segmentControl(plasmaInfo.plasmaTimer / 60);
    }
  }
  //down key
  if(g_remoteFlag & (REMOTE_DOWN_FLAG | REMOTE_DOWN_LONG_FLAG)) {
    g_remoteFlag = 0;
    if (editMode) {   // Intensity Adjust
      if(--plasmaInfo.pwr < 1)  plasmaInfo.pwr = 3;
    }
    else {            // Time Adjust
#ifdef  UNIFY_CONTINUE_OP
      continueOperation = FALSE;
#else
      plasmaInfo.continuation = FALSE;
#endif
#ifndef REDUCE_TIME_TO_TEST
      if(plasmaInfo.plasmaTimer > 5 * 60)
        plasmaInfo.plasmaTimer -= 5 * 60;
#else
      if(plasmaInfo.plasmaTimer > 5)
        plasmaInfo.plasmaTimer -= 5;
#endif
      voicePlay(SWITCH_KEY, DELAY_KEY);
//    segmentControl(plasmaInfo.plasmaTimer / 60);
    }
  }
  
  checkStart();
  checkBaseMode(0);
  checkPowerOff(STATE_POWER_OFF);
}

void handlePrepare()
{
  if(isFirstEntrance == TRUE) {
    printf("\r\n [ STATE_PREPARE : %d ]", currentState);
    isFirstEntrance = FALSE;
    RTC_TimeShow();         // SJM 200506 for Debug
    voicePlay(SWITCH_PLASMA_START, DELAY_PLASMA_START);
    Delay(DELAY_PLASMA_START);
    voicePlay(SWITCH_PREPARE, DELAY_PREPARE);
    Delay(DELAY_PREPARE);
    //segment Control
    prepareTimer = PREPARATION_TIME;    // SJM 190710 original was 30(sec);
    segmentControl(prepareTimer);
  }
  
  //blink
  {
    if(sysConfig.blinkOffFlag == TRUE)
    {
      ledControl(LED_PLASMA_ON, LED_ON);
      ledControl(LED_DIS_ON, LED_ON);
      ledControl(LED_ION_ON, LED_ON);
      
      segmentControl(prepareTimer);
      
      voicePlay(SWITCH_KEY, DELAY_KEY);
      
      sysConfig.blinkOffFlag = FALSE;
    }
    if(sysConfig.blinkOnFlag == TRUE)
    {
      ledControl(LED_PLASMA_ON, LED_OFF);
      ledControl(LED_DIS_ON, LED_OFF);
      ledControl(LED_ION_ON, LED_OFF);
      
      segmentOff();
      sysConfig.blinkOnFlag = FALSE;
    }
  }
  
  //time out -> plasma Mode Start
  if(prepareTimer <= 0) {
    currentState = STATE_STER;
    isFirstEntrance = TRUE;
  }
  //stop key -> Plasma mode Need to be Fixed REMOTE_STOP_FLAG
  if(g_remoteFlag & (REMOTE_POWER_LONG_FLAG | REMOTE_POWER_FLAG)) {
    g_remoteFlag = 0;
    //voice -> ����� �ߴ� ����
    currentState = STATE_READY_STER;
    isFirstEntrance = TRUE;
  }
     
  checkPowerOff(STATE_POWER_OFF);
}

void handlePlasmaSter()
{
  if(isFirstEntrance == TRUE) {
    printf("\r\n [ STATE_STER : %d ]", currentState);
    isFirstEntrance = FALSE;
    RTC_TimeShow();         // SJM 200506 for Debug
    control_relayAllOff();              // SJM 200506 added because of
                            // transition form continuous mode.
    segmentCycle = 1;
    pidDetect = FALSE;                  // SJM 190820 add initialize code
    plasmaBlinkOn = TRUE;
    plasmaBlinkOnTimer = 0;
    plasmaBlinkOffTimer = 0;
#ifdef  OZONE_DEPENDENT_DESTRUCTION     // SJM 190711 add '#ifdef' because of g_prvOzoneValue
    g_prvOzoneValue = FALSE;
#endif
#ifdef  INCLUDE_OZONE_CONTROL
    ozoneRangeOver = 0;
#endif
    //voice play
    voicePlay(SWITCH_PLASMA_START, DELAY_PLASMA_START);
    Delay(DELAY_PLASMA_START);
    //relay control
    control_sterOn();
    //led control
    control_sterStartLedOn();
    //���� ������ ���
//    if(plasmaInfo.Mode == PLASMA_MODE_RESERVE) {
    if(plasmaInfo.isScheduled) {    // SJM 190724 'Scheduld' start
#ifndef INCLUDE_RETURN_TO_CONTINUOUS_MODE
      plasmaInfo.plasmaTimer = 95 * 60;
      plasmaInfo.pidOn = TRUE;
#else // INCLUDE_RETURN_TO_CONTINUOUS_MODE
      continueOperation = FALSE;    // SJM 200507 
      plasmaInfo.pidOn = TRUE;
    #ifdef  REDUCE_TIME_TO_TEST
        plasmaInfo.plasmaTimer = 95;            // SJM 191018 for test-only
//        plasmaInfo.pidOn = FALSE;
    #else // REDUCE_TIME_TO_TEST
        plasmaInfo.plasmaTimer = 95 * 60;
//        plasmaInfo.pidOn = TRUE;
    #endif // REDUCE_TIME_TO_TEST
#endif  // INCLUDE_RETURN_TO_CONTINUOUS_MODE
      plasmaInfo.isScheduled = FALSE;
      plasmaInfo.pwr = 3;
    }
#ifdef  INCLUDE_STRENGTHEN_OZONE
    setTime = plasmaInfo.plasmaTimer;
        printf("\r\n[Plasma] setTime = %d(%d)\r\n",
               setTime, plasmaInfo.plasmaTimer);
#endif    
    if(plasmaInfo.pidOn == TRUE) {
      ledControl(LED_PID_ON, LED_ON);
    }
  }

  if (halfSecFlag) {
    halfSecFlag = FALSE;
    // Display Part
//    printf("[Plasma] local=%d, remote = %d\r\n",dOzoneSensoredValue, g_RemoteOzoneSensorValue);
    switch (segmentCycle) {
      case 1 :  // SJM 190810 display remained time
        if(continueOperation) segmentAlphaControl('O','n');
#ifdef  REDUCE_TIME_TO_TEST
        else         segmentControl(plasmaInfo.plasmaTimer);
#else
        else         segmentControl(plasmaInfo.plasmaTimer / 60);
#endif
        break;
      case 2 :  // SJM 190810 display local sensor value
        if(dOzoneSensoredValue < 99)
//          segmentControl( (unsigned int)(dOzoneSensoredValue -1) );
          segmentControl( (unsigned int)(dOzoneSensoredValue) );
        else  segmentControl(99);
        break;
      case 3 :  // SJM 190810 display Remote sensor value
        if( g_extOzoneSenseFlag == TRUE) {
          g_extOzoneSenseFlag = FALSE;
          segmentControl(g_RemoteOzoneSensorValue);
        }
        else  segmentAlphaControl('-','-');
        break;
    }
    if (++segmentCycle>3) segmentCycle = 1;
    ledStatus ^= 1;
    ledControl(LED_PLASMA_ON, ledStatus);

    // Control Part
#ifdef INCLUDE_OZONE_CONTROL
    if (plasmaInfo.pidOn) {
      normalPlasmaSter();
    }
    else {
    // SJM 190809 check if ozone level exceeds the limit
    if( (g_RemoteOzoneSensorValue > OZONE_RISK_LEVEL) || (dOzoneSensoredValue > OZONE_RISK_LEVEL) ) {
      reduceOzoneLevel();         // SJM 190809 add to immediate action to reduce ozone level
      ozoneRangeOver++;
      printf("{OzoneTooHigh : Local = %d , Remote = %d, Over %d\r\n",dOzoneSensoredValue, g_RemoteOzoneSensorValue,ozoneRangeOver);
      if (ozoneRangeOver>=OZONE_OVER_LIMIT) {
        voicePlay(SWITCH_OZONE_DETECT, DELAY_OZONE_DETECT);
        Delay(DELAY_OZONE_DETECT);
  #ifdef  INCLUDE_STRENGTHEN_OZONE
        operatedTime = setTime - plasmaInfo.plasmaTimer;
        printf("\r\n[Plasma] opTime = %d(%d) = %d - %d\r\n",
               operatedTime, operatedTime/60, setTime, plasmaInfo.plasmaTimer);
  #endif
        changeState(STATE_DESTRUCTION,TRUE);
      }
    }
    // SJM 190809 or ozone level is in safe range ==> Normal Operation
    else if ((g_RemoteOzoneSensorValue<=OZONE_SAFE_LEVEL)&&(dOzoneSensoredValue<=OZONE_SAFE_LEVEL) ) {
      ozoneRangeOver = 0;
      normalPlasmaSter();
      //control_sterOn();
    }
    // SJM 190809 in this case we should reduce the ozone level ( in case of PIR sensor disabled )
    else { // if (plasmaInfo.pidOn == FALSE){
      if (ozoneRangeOver) ozoneRangeOver--;
      reduceOzoneLevel();
      printf("{OzoneControlMode : Local = %d , Remote = %d\r\n",dOzoneSensoredValue, g_RemoteOzoneSensorValue);
    }
    }
#else
  #ifdef  ADD_REMOTE_OZONE_SENSOR  
    if( (g_RemoteOzoneSensorValue > 50) || (dOzoneSensoredValue > 50) ) {
      voicePlay(SWITCH_OZONE_DETECT, DELAY_OZONE_DETECT);
      Delay(DELAY_OZONE_DETECT);
    #ifdef  INCLUDE_STRENGTHEN_OZONE
      operatedTime = setTime - plasmaInfo.plasmaTimer;
        printf("\r\n[Plasma] opTime = %d(%d) = %d - %d\r\n",
               operatedTime, operatedTime/60, setTime, plasmaInfo.plasmaTimer);
    #endif
      changeState(STATE_DESTRUCTION,TRUE);
    }
  #endif
#endif  // INCLUDE_OZONE_CONTROL
  }
 
  //time over
#ifdef  UNIFY_CONTINUE_OP
  if(plasmaInfo.plasmaTimer <= 0 && continueOperation == FALSE) {
#else
  if(plasmaInfo.plasmaTimer <= 0 && plasmaInfo.continuation == FALSE) {
#endif
    //    plasmaInfo.Mode = PLASMA_MODE_READY;      SJM 190724 meaningless
#ifdef  INCLUDE_STRENGTHEN_OZONE
    operatedTime = setTime;
        printf("\r\n[Plasma] opTime = %d(%d) = %d - %d\r\n",
               operatedTime, operatedTime/60, setTime, plasmaInfo.plasmaTimer);
#endif
    changeState(STATE_DESTRUCTION,TRUE);
    printf("Time Over!!\r\n");
  }
  //PIR control
  if(plasmaInfo.pidOn == TRUE) {
    if(pidDetect == TRUE) {
      voicePlay(SWITCH_PIR_DETECT, DELAY_PIR_DETECT);
      Delay(DELAY_PIR_DETECT);
      pidDetect = FALSE;
#ifdef  INCLUDE_STRENGTHEN_OZONE
      operatedTime = setTime - plasmaInfo.plasmaTimer;
        printf("\r\n[Plasma] opTime = %d(%d) = %d - %d\r\n",
               operatedTime, operatedTime/60, setTime, plasmaInfo.plasmaTimer);
#endif
      changeState(STATE_DESTRUCTION,TRUE);
    }
  }
  //0.8v -> ���� ��ư�� ������ ���� ���� ���°� ǥ�õȴ�.
  if(g_remoteFlag & (REMOTE_ION_FLAG | REMOTE_ION_LONG_FLAG)) {
    g_remoteFlag = 0;
    segmentControl(plasmaInfo.pwr);
    Delay(800);
#ifdef  UNIFY_CONTINUE_OP
    if(continueOperation) segmentAlphaControl('O','n');
    else    segmentControl(plasmaInfo.plasmaTimer / 60);
#else
    if(plasmaInfo.continuation == FALSE)
        segmentControl(plasmaInfo.plasmaTimer / 60);
      else
        segmentAlphaControl('O','n');
#endif
  }
  //STOP
  if(g_remoteFlag & (REMOTE_OK_LONG_FLAG | REMOTE_OK_FLAG)) {
    g_remoteFlag = 0;
//    plasmaInfo.Mode = PLASMA_MODE_STOP;       SJM 190724 meaningless
    changeState(STATE_STER_STOP,TRUE);
    printf("go ster stop\r\n");
  }
  checkPowerOff(STATE_POWER_OFF);
}
  
void handlePlasmaSterStop()
{
  if(isFirstEntrance == TRUE) {
    printf("\r\n [ STATE_STER_STOP : %d ]", currentState);
    isFirstEntrance = FALSE;
    RTC_TimeShow();         // SJM 200506 for Debug
/*    
#ifdef VOICE_FIRST
    control_relayAllOff();
//    plasmaInfo.Mode = PLASMA_MODE_STOP;       SJM 190724 meaningless
    //LED and FND control
    control_sterStopLedOn();
    voicePlay(SWITCH_PLASMA_STOP, DELAY_PLASMA_STOP);
    Delay(DELAY_PLASMA_STOP);       // SJM 200421 added
#else
*/
    control_relayAllOff();
//    plasmaInfo.Mode = PLASMA_MODE_STOP;       SJM 190724 meaningless
    //LED and FND control
    control_sterStopLedOn();
//#endif
    if (continueOperation)
      segmentAlphaControl('O','n');
    else
#ifndef REDUCE_TIME_TO_TEST
      segmentControl(plasmaInfo.plasmaTimer / 60);
#else
      segmentControl(plasmaInfo.plasmaTimer);
#endif
    systemWrite();
    voicePlay(SWITCH_PLASMA_STOP, DELAY_PLASMA_STOP);
    Delay(DELAY_PLASMA_STOP);       // SJM 200421 added
    printf("Ster Stop!!\r\n");
  }
  
  //blink
  {
    if(plasmaInfo.blinkOffFlag == TRUE)
    {
      ledControl(LED_PLASMA_ON, LED_ON);
      plasmaInfo.blinkOffFlag = FALSE;
    }
    if(plasmaInfo.blinkOffFlag == TRUE)
    {
      ledControl(LED_PLASMA_ON, LED_OFF);
      plasmaInfo.blinkOnFlag = FALSE;
    }
  }
  
  //start
  if(g_remoteFlag & (REMOTE_OK_LONG_FLAG | REMOTE_OK_FLAG)) {
    g_remoteFlag = 0;
    voicePlay(SWITCH_KEY, DELAY_KEY);
    changeState(STATE_STER,FALSE);
  }
  checkBaseMode(0);
  checkPowerOff(STATE_POWER_OFF);
}

void handleDestruction()
{
  if(isFirstEntrance == TRUE) {
    printf("\r\n [ STATE_DESTRUCTION : %d ]", currentState);
    isFirstEntrance = FALSE;  
    RTC_TimeShow();         // SJM 200506 for Debug
#ifndef VOICE_FIRST
    //voice Play(����� ���� ��)
    voicePlay(SWITCH_DESTRUCTION_START, DELAY_DESTRUCTION_START);
    Delay(DELAY_DESTRUCTION_START);
    //relay Control
    control_relayAllOff();
    control_relayDestruction();
#else
    control_relayAllOff();
    //voice Play(����� ���� ��)
    voicePlay(SWITCH_DESTRUCTION_START, DELAY_DESTRUCTION_START);
    Delay(DELAY_DESTRUCTION_START);
    //relay Control
    control_relayDestruction();
#endif
    //Led Control
    control_desLed();
    segmentCycle = 1;
//    ledAllOff();    
    //Time Setting -> 30min
#ifdef  OZONE_DEPENDENT_DESTRUCTION
    if( g_prvOzoneValue == FALSE )  destructionTimer = 10 * 60;
    else                            destructionTimer = 20 * 60;
#else
  #ifndef INCLUDE_STRENGTHEN_OZONE
    #ifdef  INCLUDE_RETURN_TO_CONTINUOUS_MODE
      #ifdef  REDUCE_TIME_TO_TEST
      destructionTimer = 20;            // SJM 191018 for test-only
      #else // REDUCE_TIME_TO_TEST
      destructionTimer = 30 * 60;
      #endif // REDUCE_TIME_TO_TEST
    #else // INCLUDE_RETURN_TO_CONTINUOUS_MODE
      destructionTimer = 30 * 60;
    #endif // INCLUDE_RETURN_TO_CONTINUOUS_MODE
  #else // INCLUDE_STRENGTHEN_OZONE
    #ifndef REDUCE_TIME_TO_TEST
      destructionTimer = operatedTime/60;
      if (destructionTimer<30)      destructionTimer=30;
      else if (destructionTimer>60) destructionTimer=60;
      destructionTimer *= 60;
    #else
      destructionTimer = operatedTime;
      if (destructionTimer<30)      destructionTimer=30;
      else if (destructionTimer>60) destructionTimer=60;
    #endif
      printf("\r\n[Destruction] timer = %d (%d)\r\n",destructionTimer,operatedTime);
  #endif
#endif // OZONE_DEPENDENT_DESTRUCTION
    //segment Control
#ifndef REDUCE_TIME_TO_TEST
    segmentControl(destructionTimer / 60);
#else
    segmentControl(destructionTimer);
#endif
  }
#if 0  
  //blink
  {
    if(sysConfig.blinkOffFlag == TRUE)
    {
      ledControl(LED_PLASMA_ON, LED_ON);
      ledControl(LED_DIS_ON, LED_ON);
      ledControl(LED_ION_ON, LED_ON);
      
      segmentControl(destructionTimer / 60);
      sysConfig.blinkOffFlag = FALSE;
    }
    if(sysConfig.blinkOnFlag == TRUE)
    {
      ledControl(LED_PLASMA_ON, LED_OFF);
      ledControl(LED_DIS_ON, LED_OFF);
      ledControl(LED_ION_ON, LED_OFF);
      
      segmentOff();
      sysConfig.blinkOnFlag = FALSE;
    }
  }
#endif
  if (halfSecFlag) {
    halfSecFlag = FALSE;
//    printf("[Plasma] local=%d, remote = %d\r\n",dOzoneSensoredValue, g_RemoteOzoneSensorValue);
    switch (segmentCycle) {
      case 1 :  // SJM 190810 display remained time
#ifndef REDUCE_TIME_TO_TEST
        segmentControl(destructionTimer / 60);
#else
        segmentControl(destructionTimer);
#endif
        break;
      case 2 :  // SJM 190810 display local sensor value
        if(dOzoneSensoredValue < 99)
//          segmentControl( (unsigned int)(dOzoneSensoredValue -1) );
          segmentControl( (unsigned int)(dOzoneSensoredValue) );
        else  segmentControl(99);
        break;
      case 3 :  // SJM 190810 display Remote sensor value
        if( g_extOzoneSenseFlag == TRUE) {
          g_extOzoneSenseFlag = FALSE;
          segmentControl(g_RemoteOzoneSensorValue);
        }
        else  segmentAlphaControl('-','-');
        break;
    }
    if (++segmentCycle>3) segmentCycle = 1;
    ledStatus ^= 1;
    ledControl(LED_PLASMA_ON, ledStatus);
    ledControl(LED_DIS_ON, ledStatus);
    ledControl(LED_ION_ON, ledStatus);
  }
  
  {
     //REDLed();
  }
  
#ifdef  STAND_TYPE_ENABLE    
    if(fanBlinkOffFlag == TRUE) {
      relayControl(RELAY_AC_FAN1, RELAY_ON);
      fanBlinkOffFlag = FALSE;
      RTC_TimeShow();
      printf(" FAN_1_ON : %0.2d:%0.2d:%0.2d \n\r", RTC_TimeStructure.RTC_Hours, RTC_TimeStructure.RTC_Minutes, RTC_TimeStructure.RTC_Seconds);
    }
    if(fanBlinkOnFlag == TRUE) {
      relayControl(RELAY_AC_FAN1, RELAY_OFF);
      fanBlinkOnFlag = FALSE;        
      RTC_TimeShow();
      printf(" FAN_1_OFF : %0.2d:%0.2d:%0.2d \n\r", RTC_TimeStructure.RTC_Hours, RTC_TimeStructure.RTC_Minutes, RTC_TimeStructure.RTC_Seconds);
    }
#endif  
  
  //time over -> �ö�� Ready
#ifndef INCLUDE_RETURN_TO_CONTINUOUS_MODE
  if(destructionTimer <= 0) changeState(STATE_READY_STER,TRUE);
#else
  if(destructionTimer <= 0) {
    if (returnToContinuousOperation)
      continueOperation = TRUE;
    changeState(prevOperation,TRUE);
/*
    if (returnToContinuousOperation) {
      continueOperation = TRUE;
      if ((prevOperation==STATE_DIS)||(prevOperation==STATE_ION))
        changeState(prevOperation,TRUE);
      else 
        changeState(STATE_READY_STER,TRUE);
    }
    else changeState(STATE_READY_STER,TRUE);
*/  }
#endif
  //��ž Ű -> �ö�� Ready
  if(g_remoteFlag & (REMOTE_OK_FLAG | REMOTE_OK_LONG_FLAG)) {
    g_remoteFlag = 0;
    control_relayAllOff();
    //voice Play(����� �ߴ� ��)
    voicePlay(SWITCH_DESTRUCTION_STOP, DELAY_DESTRUCTION_STOP);
    Delay(DELAY_DESTRUCTION_STOP);
    changeState(STATE_READY_STER,TRUE);
  }
  //���� Ű -> Power Off
  checkPowerOff(STATE_POWER_OFF);
}

void handleReadyDisinfect()
{
  if(isFirstEntrance == TRUE) {
    printf("\r\n [ STATE_READY_DIS : %d ]", currentState);
    isFirstEntrance = FALSE;
    RTC_TimeShow();         // SJM 200506 for Debug
    //relay Control
    control_relayAllOff();
    //LED control
    control_disLed();
//    pidLEDOnFlag = FALSE;     SJM 190711 always assigned to 'FALSE' & never used
    //DIS FND
#ifdef  UNIFY_CONTINUE_OP
    continueOperation = FALSE;
#else
    disInfo.continuation = FALSE;
#endif
    disInfo.disTimer = 60 * 60;
    segmentControl(disInfo.disTimer / 60);
    voicePlay(SWITCH_DISINFECT_MODE, DELAY_DISINFECT_MODE);
    Delay(DELAY_DISINFECT_MODE);
  }
  
  //�ð� ��
  if(g_remoteFlag & (REMOTE_UP_FLAG | REMOTE_UP_LONG_FLAG)) {
    g_remoteFlag = 0;
    voicePlay(SWITCH_KEY, DELAY_KEY);
    if(disInfo.disTimer < 60 * 60)  disInfo.disTimer += 5 * 60;  
#ifdef  UNIFY_CONTINUE_OP
    continueOperation = FALSE;
#else
    disInfo.continuation = FALSE;
#endif
    segmentControl(disInfo.disTimer / 60);
  }
  //�ð� �ٿ�
  if(g_remoteFlag & (REMOTE_DOWN_FLAG | REMOTE_DOWN_LONG_FLAG)) {
    g_remoteFlag = 0;
    voicePlay(SWITCH_KEY, DELAY_KEY);
    if(disInfo.disTimer > 5 * 60) disInfo.disTimer -= 5 * 60;
#ifdef  UNIFY_CONTINUE_OP
    continueOperation = FALSE;
#else
    disInfo.continuation = FALSE;
#endif
    segmentControl(disInfo.disTimer / 60);
  }

  if(g_remoteFlag & REMOTE_WIND_LONG_FLAG) {
    g_remoteFlag = 0;
    //continue
#ifdef  UNIFY_CONTINUE_OP
    continueOperation = TRUE;
#else
    disInfo.continuation = TRUE;
#endif
    segmentAlphaControl('O', 'n');
  }
  //start
  checkStart();
  checkBaseMode(0);
  checkPowerOff(STATE_POWER_OFF);
}

//��ո��
void handleDisinfect()
{
  if(isFirstEntrance == TRUE) {
    printf("\r\n [ STATE_DIS : %d ]", currentState);
    isFirstEntrance = FALSE;
    RTC_TimeShow();         // SJM 200506 for Debug
    control_relayAllOff();              // SJM 200506 added because of
                            // transition form continuous mode.
    voicePlay(SWITCH_STERILIZATION_START, DELAY_STER_START);
    Delay(DELAY_STER_START);
    //LED display
    control_disLed();
    //relay control
    control_disRelayOn();
#ifdef  STAND_TYPE_ENABLE
    fanBlinkOn = TRUE;
    fanBlinkOnTimer = 0;
    fanBlinkOffTimer = 0;
#endif
  }
  
  //blink
  {
    if(disInfo.blinkOffFlag == TRUE)
    {
      ledControl(LED_DIS_ON, LED_ON);
#ifdef  UNIFY_CONTINUE_OP
      if (continueOperation) segmentAlphaControl('O', 'n');
      else          segmentControl(disInfo.disTimer / 60);
#else      
      if(disInfo.continuation == FALSE)
        segmentControl(disInfo.disTimer / 60);
      else
        segmentAlphaControl('O', 'n');
#endif      
      disInfo.blinkOffFlag = FALSE;
    }
    if(disInfo.blinkOnFlag == TRUE)
    {
      ledControl(LED_DIS_ON, LED_OFF);
      segmentOff();
      
      disInfo.blinkOnFlag = FALSE;
    }
  }
#ifdef  STAND_TYPE_ENABLE    
    if(fanBlinkOffFlag == TRUE)
    {
      relayControl(RELAY_AC_FAN1, RELAY_ON);
      fanBlinkOffFlag = FALSE;
//      RTC_TimeShow();
//      printf("\n\r FAN_1_ON : %0.2d:%0.2d:%0.2d \n\r", RTC_TimeStructure.RTC_Hours, RTC_TimeStructure.RTC_Minutes, RTC_TimeStructure.RTC_Seconds);
    }
    
    if(fanBlinkOnFlag == TRUE)
    {
      relayControl(RELAY_AC_FAN1, RELAY_OFF);
      fanBlinkOnFlag = FALSE;        
//      RTC_TimeShow();
//      printf("\n\r FAN_1_OFF : %0.2d:%0.2d:%0.2d \n\r", RTC_TimeStructure.RTC_Hours, RTC_TimeStructure.RTC_Minutes, RTC_TimeStructure.RTC_Seconds);
    }
#endif
  
  //Disinfect Stop
  if(g_remoteFlag & (REMOTE_OK_LONG_FLAG | REMOTE_OK_FLAG)) {
    g_remoteFlag = 0;
    changeState(STATE_DIS_STOP,TRUE);
  }
  //time over
#ifdef  UNIFY_CONTINUE_OP
  if(disInfo.disTimer <= 0 && continueOperation == FALSE)
#else
  if(disInfo.disTimer <= 0 && disInfo.continuation == FALSE)
#endif
    changeState(STATE_READY_DIS,TRUE);
  checkPowerOff(STATE_POWER_OFF);
#if 0  // SJM 190711 never used
  //Time update
  if(exMin != (disInfo.disTimer / 60))
  {
    exMin = disInfo.disTimer / 60;
  }
#endif
}

void handleDisinfectStop()
{
  if(isFirstEntrance == TRUE) {
    printf("\r\n [ STATE_DIS_STOP : %d ]", currentState);
    isFirstEntrance = FALSE;
    RTC_TimeShow();         // SJM 200506 for Debug
#ifndef VOICE_FIRST
    //voice play
    voicePlay(SWITCH_STERILIZATION_STOP, DELAY_STER_STOP);
    Delay(DELAY_STER_STOP);
#endif
    //LED display
    control_disLed();
    //relay control
    control_relayAllOff();    // SJM 190711 instead of control_disRelayOff();
    systemWrite();
    //FND control
#ifdef  UNIFY_CONTINUE_OP
    if (continueOperation)  segmentAlphaControl('O', 'n');
    else            segmentControl(disInfo.disTimer / 60);
#else
    if(disInfo.continuation == FALSE)
      segmentControl(disInfo.disTimer / 60);
    else
      segmentAlphaControl('O', 'n');
#endif
#ifdef VOICE_FIRST
    //voice play
    voicePlay(SWITCH_STERILIZATION_STOP, DELAY_STER_STOP);
    Delay(DELAY_STER_STOP);
#endif
  }
  
  //blink
  {
    if(disInfo.blinkOffFlag == TRUE)
    {
      ledControl(LED_DIS_ON, LED_ON);
      
      disInfo.blinkOffFlag = FALSE;
    }
    if(disInfo.blinkOnFlag == TRUE)
    {
      ledControl(LED_DIS_ON, LED_OFF);
      
      disInfo.blinkOnFlag = FALSE;
    }
  }
  
  //restart
  if(g_remoteFlag & (REMOTE_OK_LONG_FLAG | REMOTE_OK_FLAG)) {
    g_remoteFlag = 0;
    isFirstEntrance = TRUE;
    currentState = STATE_DIS;
  }
  checkBaseMode(0);
  checkPowerOff(STATE_POWER_OFF);
}

//���̿� ���
void handleReadyIon()
{
  if(isFirstEntrance == TRUE) {
    printf("\r\n [ STATE_READY_ION : %d ]", currentState);
    isFirstEntrance = FALSE;
    RTC_TimeShow();         // SJM 200506 for Debug
//#ifdef VOICE_FIRST
//    voicePlay(SWITCH_ANION_MODE, DELAY_ANION_MODE);
//    Delay(DELAY_ANION_MODE);
//#endif
    //LED control
    control_ionLed();
    //relay Control
    control_relayAllOff();
//    pidLEDOnFlag = FALSE;     SJM 190711 always assigned to 'FALSE' & never used
    //FND display
    ionInfo.ionTimer = 60 * 60;
#ifdef  UNIFY_CONTINUE_OP
    continueOperation = FALSE;
#else
    ionInfo.continuation = FALSE;
#endif
    segmentControl(ionInfo.ionTimer / 60);
//#ifndef VOICE_FIRST
    voicePlay(SWITCH_ANION_MODE, DELAY_ANION_MODE);
    Delay(DELAY_ANION_MODE);
//#endif
  }

  //time up
  if(g_remoteFlag & (REMOTE_UP_FLAG | REMOTE_UP_LONG_FLAG)) {
    g_remoteFlag = 0;
    voicePlay(SWITCH_KEY, DELAY_KEY);
    if(ionInfo.ionTimer < 95 * 60)  ionInfo.ionTimer += 5 * 60;  
#ifdef  UNIFY_CONTINUE_OP
    continueOperation = FALSE;
#else
    ionInfo.continuation = FALSE;
#endif
    segmentControl(ionInfo.ionTimer / 60);
  }
  //time down
  if(g_remoteFlag & (REMOTE_DOWN_FLAG | REMOTE_DOWN_LONG_FLAG)) {
    g_remoteFlag = 0;
    voicePlay(SWITCH_KEY, DELAY_KEY);
    if(ionInfo.ionTimer > 5 * 60) ionInfo.ionTimer -= 5 * 60;  
#ifdef  UNIFY_CONTINUE_OP
    continueOperation = FALSE;
#else
    ionInfo.continuation = FALSE;
#endif
    segmentControl(ionInfo.ionTimer / 60);
  }
  //time continue
  if(g_remoteFlag & (REMOTE_WIND_LONG_FLAG)) {
    g_remoteFlag = 0;
    printf("continue mode!!\r\n");
#ifdef  UNIFY_CONTINUE_OP
    continueOperation = TRUE;
#else
    ionInfo.continuation = TRUE;
#endif
    segmentAlphaControl('O', 'n');
  }
  
  if(g_remoteFlag & (BUTTON_CONFIRM_LONG)) {
      g_remoteFlag = 0;
      changeState(STATE_SETUP_MODE,FALSE);
  }
  checkStart();
  checkBaseMode(0);
  checkPowerOff(STATE_POWER_OFF);
}

void handleIon()
{
  if(isFirstEntrance == TRUE) {
    printf("\r\n [ STATE_ION : %d ]", currentState);
    isFirstEntrance = FALSE;
    RTC_TimeShow();         // SJM 200506 for Debug
    control_relayAllOff();              // SJM 200506 added because of
                            // transition form continuous mode.
#ifdef VOICE_FIRST
    voicePlay(SWITCH_ION_START, DELAY_ION_START);
    Delay(DELAY_ION_START);
#endif
    //led control
    control_ionLed();
    //relay control
    control_IonOn();
    //FND control
#ifdef  UNIFY_CONTINUE_OP
    if (continueOperation)  segmentAlphaControl('O', 'n');
    else            segmentControl(ionInfo.ionTimer / 60);
#else
    if(ionInfo.continuation == FALSE)
      segmentControl(ionInfo.ionTimer / 60);
    else
      segmentAlphaControl('O', 'n');
#endif
#ifndef VOICE_FIRST
    voicePlay(SWITCH_ION_START, DELAY_ION_START);
    Delay(DELAY_ION_START);
#endif
#ifdef  STAND_TYPE_ENABLE
    fanBlinkOn = TRUE;
    fanBlinkOnTimer = 0;
    fanBlinkOffTimer = 0;
#endif
  }
  
  //blink
  {
    if(ionInfo.blinkOffFlag == TRUE) {
      ledControl(LED_ION_ON, LED_ON);
#ifdef  UNIFY_CONTINUE_OP
      if (continueOperation)  segmentAlphaControl('O', 'n');
      else            segmentControl(ionInfo.ionTimer / 60);
#else
      if(ionInfo.continuation == FALSE)
        segmentControl(ionInfo.ionTimer / 60);
      else
        segmentAlphaControl('O', 'n');
#endif
      ionInfo.blinkOffFlag = FALSE;
    }
    if(ionInfo.blinkOnFlag == TRUE) {
      ledControl(LED_ION_ON, LED_OFF);
      segmentOff();
      ionInfo.blinkOnFlag = FALSE;
    }
  }

#ifdef  STAND_TYPE_ENABLE    
    if(fanBlinkOffFlag == TRUE) {
      relayControl(RELAY_AC_FAN1, RELAY_ON);
      fanBlinkOffFlag = FALSE;
//      RTC_TimeShow();
//      printf("\n\r FAN_1_ON : %0.2d:%0.2d:%0.2d \n\r", RTC_TimeStructure.RTC_Hours, RTC_TimeStructure.RTC_Minutes, RTC_TimeStructure.RTC_Seconds);
    }
    if(fanBlinkOnFlag == TRUE) {
      relayControl(RELAY_AC_FAN1, RELAY_OFF);
      fanBlinkOnFlag = FALSE;        
//      RTC_TimeShow();
//      printf("\n\r FAN_1_OFF : %0.2d:%0.2d:%0.2d \n\r", RTC_TimeStructure.RTC_Hours, RTC_TimeStructure.RTC_Minutes, RTC_TimeStructure.RTC_Seconds);
    }
#endif
  
  //time Over
#ifdef  UNIFY_CONTINUE_OP
  if(ionInfo.ionTimer <= 0 && continueOperation == FALSE)
#else
  if(ionInfo.ionTimer <= 0 && ionInfo.continuation == FALSE)
#endif
    changeState(STATE_READY_ION,TRUE);
  //ion Stop
  if(g_remoteFlag & (REMOTE_OK_LONG_FLAG | REMOTE_OK_FLAG)) {
    g_remoteFlag = 0;
//    voicePlay(SWITCH_KEY, DELAY_KEY);
    changeState(STATE_ION_STOP,TRUE);
  }
  checkPowerOff(STATE_POWER_OFF);
#if 0  // SJM 190711 never used
  //Time update
  if(exMin != (ionInfo.ionTimer / 60))
  {
    exMin = ionInfo.ionTimer / 60;
  }
#endif
}

void handleIonStop()
{
  if(isFirstEntrance == TRUE) {
    printf("\r\n [ STATE_ION_STOP : %d ]", currentState);
    isFirstEntrance = FALSE;
    RTC_TimeShow();         // SJM 200506 for Debug
#ifndef VOICE_FIRST
    voicePlay(SWITCH_ION_STOP, DELAY_ION_STOP);
    Delay(DELAY_ION_STOP);
#endif
    //led control
    control_ionLed(); 
    //relay control
    control_relayAllOff();    // SJM 190711 instead of control_IonOff();
    systemWrite();
    //FND control
#ifdef  UNIFY_CONTINUE_OP
    if (continueOperation)  segmentAlphaControl('O', 'n');
    else            segmentControl(ionInfo.ionTimer / 60);
#else
    if(ionInfo.continuation == FALSE)
      segmentControl(ionInfo.ionTimer / 60);
    else
      segmentAlphaControl('O', 'n');
#endif
#ifdef VOICE_FIRST
    voicePlay(SWITCH_ION_STOP, DELAY_ION_STOP);
    Delay(DELAY_ION_STOP);
#endif    
  }

  //blink
  {
    if(ionInfo.blinkOffFlag == TRUE) {
      ledControl(LED_ION_ON, LED_ON);
      ionInfo.blinkOffFlag = FALSE;
    }
    if(ionInfo.blinkOnFlag == TRUE) {
      ledControl(LED_ION_ON, LED_OFF);
      ionInfo.blinkOnFlag = FALSE;
    }
  }
  
  //restart
  if(g_remoteFlag & (REMOTE_OK_LONG_FLAG | REMOTE_OK_FLAG)) {
    g_remoteFlag = 0;
    isFirstEntrance = TRUE;
    currentState = STATE_ION;
  }

  checkBaseMode(0);
  checkPowerOff(STATE_POWER_OFF);
}

void ledSequence(unsigned char step)
{
    if (step<(LED_PID_ON*4)) {
      ledControl(step/4+1,(step+1)%2);
    }
    else if (step< 80){
      if (step%2) ledAllOff();
      else        ledAllOn();
    }
    else if (step<90) {
      segmentControl((step%10)*11);
    }
    else {
      switch (step) {
        case 90 :
          segmentAlphaControl('E','O');
          break;
        case 91 :
          segmentAlphaControl('O','U');
          break;
        case 92 :
          segmentAlphaControl('U','F');
          break;
        case 93 :
          segmentAlphaControl('F','n');
          break;
        case 94 :
          segmentAlphaControl('n','-');
          break;
        case 95 :
          segmentAlphaControl('-','E');
          break;
        case 96 :
          segmentOff();
          break;
        default :
          break;
      }
    }
}

void handleEngineerMode()
{
  static unsigned char port, onOff[MAX_RELAY_NUM]; //, opMode;
  static unsigned char m_usbUpgrade;
  static unsigned int ledStep, opMode, ozoneStep;
//  static unsigned char ledStep;
  
  if(isFirstEntrance == TRUE) {
    printf("\r\n [ STATE_ENGINEER_MODE : %d ]", currentState);
    isFirstEntrance = FALSE;
    RTC_TimeShow();         // SJM 200506 for Debug
    //led control
//    control_engineerLed();
    ledAllOff();
    //segment control
    segmentControl(SW_VERSION);
    //relay all off
    control_relayAllOff();
    ledStep = ozoneStep = 0;
    opMode = 0;   // 0-relay on/Off
    for (port=0; port<MAX_RELAY_NUM; port++) onOff[port] = 0;
    port = 0;
    m_usbUpgrade = FALSE;
    voicePlay(SWITCH_ENGINEER_MODE, DELAY_ENGINEER_MODE);
    Delay(DELAY_ENGINEER_MODE);
    printf("\r\n Engineer Mode\r\n");
  }
  
  switch (opMode) {
    case 0 :    // relay on/Off Test
      if (g_remoteFlag & (BUTTON_UP | BUTTON_UP_LONG) ) {
        g_remoteFlag = 0; m_usbUpgrade = FALSE;
        ledControl(port+1,LED_OFF);
        port++;
        if (port>=MAX_RELAY_NUM) port = 0;
        ledControl(port+1,LED_ON);
      }
      else if (g_remoteFlag & (BUTTON_DOWN | BUTTON_DOWN_LONG) ) {
        g_remoteFlag = 0; m_usbUpgrade = FALSE;
        ledControl(port+1,LED_OFF);
        if (port==0) port = MAX_RELAY_NUM-1;
        else          port--;
        ledControl(port+1,LED_ON);
      }
      else if (g_remoteFlag & (BUTTON_RIGHT | BUTTON_RIGHT_LONG) ) {
        g_remoteFlag = 0; m_usbUpgrade = FALSE;
        onOff[port] ^= 1;
        relayControl(port+1,onOff[port]);
      }
      segmentControl((port+1)*10+onOff[port]);
      break;
    case 1 :    // sequential led on/off test --> ozone limit 200511 upon JHK's request(Spain)
      if (halfSecFlag) {
        halfSecFlag = FALSE;
      if (g_remoteFlag & (BUTTON_UP | BUTTON_UP_LONG) ) {
        g_remoteFlag = 0; m_usbUpgrade = FALSE;
        sysConfig.ozoneLimit += 5;
        if (sysConfig.ozoneLimit>= OZONE_LIMIT_MAX) {
          sysConfig.ozoneLimit = OZONE_LIMIT_MAX;
          voicePlay(SWITCH_KEY, DELAY_KEY); Delay(DELAY_KEY);
        }
      }
      else if (g_remoteFlag & (BUTTON_DOWN | BUTTON_DOWN_LONG) ) {
        g_remoteFlag = 0; m_usbUpgrade = FALSE;
        sysConfig.ozoneLimit -= 5;
        if (sysConfig.ozoneLimit<= OZONE_LIMIT_MIN) {
          sysConfig.ozoneLimit = OZONE_LIMIT_MIN;
          voicePlay(SWITCH_KEY, DELAY_KEY); Delay(DELAY_KEY);
        }
      }
      else if (g_remoteFlag & (BUTTON_CONFIRM | BUTTON_CONFIRM_LONG) ) {
        g_remoteFlag = 0; m_usbUpgrade = FALSE;
        voicePlay(SWITCH_KEY, DELAY_KEY); Delay(DELAY_KEY);
        systemWrite();
        printf("\r\n [Ozone Limit = %d]\r\n",sysConfig.ozoneLimit);
      }
      segmentControl(sysConfig.ozoneLimit);
  #if 0     // 200511 SJM change to ozone limit upon JHK's request(Spain)
        printf("\r\n {Here!!! opMode = %d, ledStep = %d\r\n", opMode, ledStep);
        ledSequence(ledStep);
        ledStep++;
        if (ledStep>=97) ledStep = 0;
  #endif // 0
      }
      break;
    case 2 :    // Ozone Sensor Display
      if (halfSecFlag) {
        halfSecFlag = FALSE;
      printf("[Eng] Local = %d , Remote = %d\r\n",dOzoneSensoredValue, g_RemoteOzoneSensorValue);
        // Disp Ozone Sensor Value
        if (ozoneStep) {
          ozoneStep = 0;
          if( g_extOzoneSenseFlag == TRUE) {
             g_extOzoneSenseFlag = FALSE;
             segmentControl(g_RemoteOzoneSensorValue);
          }
          else {
            segmentAlphaControl('-','-');
          }
        }
        else {
          ozoneStep++;
          if(dOzoneSensoredValue < 99)
//                segmentControl( (unsigned int)(dOzoneSensoredValue -1) );
                segmentControl( (unsigned int)(dOzoneSensoredValue) );
          else  segmentControl(99);
        }
      }
      break;
  }

  if (g_remoteFlag & (BUTTON_TIME | BUTTON_TIME_LONG)) {
    g_remoteFlag = 0; m_usbUpgrade = FALSE;
    opMode = 0;       // relay on/Off test
    printf("\r\n opMode1 = %d\r\n", opMode);
  }
  if (g_remoteFlag & (BUTTON_INTENSITY | BUTTON_INTENSITY_LONG)) {
    g_remoteFlag = 0; m_usbUpgrade = FALSE;
    opMode = 1;       // LED test
    printf("\r\n opMode2 = %d\r\n", opMode);
  }
  if (g_remoteFlag & (BUTTON_HUMAN | BUTTON_HUMAN_LONG)) {
    g_remoteFlag = 0; m_usbUpgrade = FALSE;
    opMode = 2;       // Ozone Sensor test
    printf("\r\n opMode2 = %d\r\n", opMode);
  }
  // S/W upgrade!!!
#if 0
  if (g_remoteFlag & (BUTTON_PERIOD_LONG)) {
    g_remoteFlag = 0;
    if(m_usbUpgrade == FALSE) {
      //voice play(KEY)
      voicePlay(SWITCH_KEY, DELAY_KEY);
      m_usbUpgrade = TRUE;  
    }
    else {
      //voice play(KEY)
      voicePlay(SWITCH_KEY, DELAY_KEY); Delay(DELAY_KEY);
      voicePlay(SWITCH_KEY, DELAY_KEY); Delay(DELAY_KEY);
      UpgradeEEPWrite(UpgradeEEPdata);
      NVIC_SystemReset();
    }
  }
#endif
  if (g_remoteFlag & (BUTTON_ANION_LONG)) {     // prepare to Upgrade
    g_remoteFlag = 0;
    m_usbUpgrade = TRUE;
    //voice play(KEY)
    voicePlay(SWITCH_KEY, DELAY_KEY);
  }
  if (g_remoteFlag & (BUTTON_DISINFECT_LONG)) {
    g_remoteFlag = 0;
    if (m_usbUpgrade == TRUE) {
      //voice play(KEY)
      voicePlay(SWITCH_KEY, DELAY_KEY); Delay(DELAY_KEY);
      voicePlay(SWITCH_KEY, DELAY_KEY); Delay(DELAY_KEY);
      UpgradeEEPWrite(UpgradeEEPdata);
      NVIC_SystemReset();
    }
  }
  if (g_remoteFlag & (BUTTON_PLASMA_LONG)) {
    g_remoteFlag = 0;
    if (m_usbUpgrade==TRUE) {
      m_usbUpgrade = FALSE;
      voicePlay(SWITCH_CONSUMABLE_CHECK, DELAY_CONSUMABLE_CHECK); 
      Delay(DELAY_CONSUMABLE_CHECK);
      sysConfig.uvLampCountMin = 0;
      sysConfig.ozoneLampCountMin = 0;
      sysConfig.filterCountMin = 0;
      sysConfig.rciOperatingMin = 0;
      sysConfig.prevState = DEFAULT_STATE;
      plasmaInfo.rsvOn = FALSE;
      // SJM 200511 added Initialization
      sysConfig.ozoneLimit = OZONE_LIMIT_DEFAULT;
      plasmaInfo.rsvTime = 1;
      plasmaInfo.pidOn = TRUE;
      plasmaInfo.pwr = 3;
      plasmaInfo.isScheduled = FALSE;
      
      systemWrite();
    }
  }
      
  checkPowerOff(STATE_POWER_OFF);
}

void copyTime()
{
    RTC_TimeShow();
    RTC_GetTime(RTC_Format_BIN, &curTime);
    printf("  The current time (Hour-Minute-Second) is :  %0.2d:%0.2d:%0.2d \n\r", 
           curTime.RTC_Hours, curTime.RTC_Minutes, curTime.RTC_Seconds);
    tempHour = (unsigned char)curTime.RTC_Hours;
    tempMin = (unsigned char)curTime.RTC_Minutes;
    printf(" tempTime = %02d:%02d",tempHour,tempMin);
}

void handleSetup()
{
  static unsigned char hourMin, settingMode,engModeReady;
  
  if (isFirstEntrance) {
    printf("\r\n [ STATE_SETUP_MODE : %d ]", currentState);
    isFirstEntrance = FALSE;
    RTC_TimeShow();         // SJM 200506 for Debug
#ifdef VOICE_FIRST
    voicePlay(SWITCH_SETUP_MODE, DELAY_SETUP_MODE);
    Delay(DELAY_SETUP_MODE);
#endif
//    ledStatus = 0;
    engModeReady = FALSE;
    settingMode = SET_TIME;
    hourMin = 0;    // 0 = hour mode, 1 = minute mode
    copyTime();
    tempRsvTime = plasmaInfo.rsvTime;
    tempRsvFlag = plasmaInfo.rsvOn;
    printf("[1]select rsvOn : %d\r\n", plasmaInfo.rsvOn);
    printf("[1]select rsvTime : %d\r\n", plasmaInfo.rsvTime);
    
    ledAllOff();
    ledControl(LED_POWER_SIG1,LED_ON);
    ledControl(LED_POWER_SIG2,LED_ON);
    ledControl(LED_SETTING_SIG1,LED_ON);
    ledControl(LED_SETTING_SIG2,LED_ON);
#ifndef VOICE_FIRST
    voicePlay(SWITCH_SETUP_MODE, DELAY_SETUP_MODE);
    Delay(DELAY_SETUP_MODE);
#endif
  }
  
  if (halfSecFlag) {
    halfSecFlag = FALSE;
    ledStatus ^= 1;
    switch (settingMode) {
      case SET_PLASMA_RESERVATION :
        ledControl(LED_PLASMA_FONT, ledStatus);
        ledControl(LED_RESERVE_FONT,LED_OFF);
        break;
      case SET_TIME :
      default :
        ledControl(LED_PLASMA_FONT, LED_OFF);
        ledControl(LED_RESERVE_FONT,ledStatus);
        break;
    }
  }

  switch (settingMode) {
    case SET_PLASMA_RESERVATION :
      ledControl(LED_PLASMA_ON,tempRsvFlag);
      if (tempRsvFlag)  segmentControl(tempRsvTime);
      else              segmentAlphaControl('n','o');
      break;
    case SET_TIME :
    default :
      if (hourMin) {
//      ledConrol(LED_RESERVE_ON,LED_OFF);
        segmentControl(tempMin);
      }
      else {
//      ledConrol(LED_RESERVE_ON,LED_ON);
        segmentControl(tempHour);
      }
      break;
  }
  
  if ( g_remoteFlag&(BUTTON_CONFIRM|BUTTON_CONFIRM_LONG) ) {
    if ((engModeReady==TRUE)&&(g_remoteFlag&BUTTON_CONFIRM_LONG)) {
      // enter Engineer Mode
      g_remoteFlag = 0;
//      voicePlay(SWITCH_KEY, DELAY_KEY);
//      Delay(DELAY_KEY);
      changeState(STATE_ENGINEER_MODE,FALSE);
    }
    else {    // Normal operation
      g_remoteFlag = 0; engModeReady = FALSE;
      switch (settingMode) {
        case SET_PLASMA_RESERVATION :
          plasmaInfo.rsvOn = tempRsvFlag;
          plasmaInfo.rsvTime = tempRsvTime;  
          printf("[2]select rsvOn : %d\r\n", plasmaInfo.rsvOn);
          printf("[2]select rsvTime : %d\r\n", plasmaInfo.rsvTime);
          systemWrite();
          break;
        case SET_TIME :
        default :
          RTC_TimeShow();
          printf(" tempTime = %02d:%02d",tempHour,tempMin);
          if (hourMin)  curTime.RTC_Minutes = tempMin;
          else          curTime.RTC_Hours = tempHour;
          printf("\n\r  The current time (Hour-Minute-Second) is :  %0.2d:%0.2d:%0.2d ", 
               curTime.RTC_Hours, curTime.RTC_Minutes, curTime.RTC_Seconds);
          RTC_SetTime(RTC_Format_BIN,&curTime);
          RTC_TimeShow();
          break;
      }
      voicePlay(SWITCH_KEY, DELAY_KEY);
      Delay(DELAY_KEY);
    }
  }
  if ( g_remoteFlag&(BUTTON_UP|BUTTON_UP_LONG) ) {
    g_remoteFlag = 0; engModeReady = FALSE;
    switch (settingMode) {
      case SET_PLASMA_RESERVATION :
        tempRsvTime++;
        tempRsvTime = tempRsvTime%24;
        break;
      case SET_TIME :
      default :
        if (hourMin) {
          tempMin++;  
          tempMin = tempMin%60;
        }
        else {
          tempHour++;
          tempHour = tempHour%24;
        }
        break;
    }
  } 
  if ( g_remoteFlag&(BUTTON_DOWN|BUTTON_DOWN_LONG) ) {
    g_remoteFlag = 0; engModeReady = FALSE;
    switch (settingMode) {
      case SET_PLASMA_RESERVATION :
        if (tempRsvTime==0) tempRsvTime = 23;
        else                tempRsvTime--;
        break;
      case SET_TIME :
      default :
        if (hourMin) {
          if (tempMin==0) tempMin = 59;
          else            tempMin--;  
        }
        else {
          if (tempHour==0) tempHour = 23;
          else            tempHour--;  
        }
        break;
    }
  } 
  if ( g_remoteFlag&(BUTTON_RIGHT|BUTTON_RIGHT_LONG) ) {
    g_remoteFlag = 0; engModeReady = FALSE;
    voicePlay(SWITCH_KEY, DELAY_KEY);
    Delay(DELAY_KEY);
    switch (settingMode) {
      case SET_PLASMA_RESERVATION :
        tempRsvFlag ^= 1;   // toggle On-Off
        break;
      case SET_TIME :       // fall-through
      default :
        hourMin ^= 1;       // toggle btw hour & min
        copyTime();         // refresh time from RTC
        ledControl(LED_RESERVE_ON,hourMin);
        break;
    }
  }
  if ( g_remoteFlag&(BUTTON_PLASMA|BUTTON_PLASMA_LONG) ) {
    g_remoteFlag = 0; engModeReady = FALSE;
    settingMode = SET_PLASMA_RESERVATION;
    tempRsvTime = plasmaInfo.rsvTime;
    tempRsvFlag = plasmaInfo.rsvOn;
      printf("[3]select rsvOn : %d\r\n", plasmaInfo.rsvOn);
      printf("[3]select rsvTime : %d\r\n", plasmaInfo.rsvTime);
    voicePlay(SWITCH_KEY, DELAY_KEY);
    Delay(DELAY_KEY);
  }
  if ( g_remoteFlag&(BUTTON_TIME|BUTTON_TIME_LONG) ) {
    g_remoteFlag = 0; engModeReady = FALSE;
    settingMode = SET_TIME;
    hourMin = 0;   // re-initialize
    copyTime();     // refresh time from RTC
    ledControl(LED_RESERVE_ON,hourMin);
    voicePlay(SWITCH_KEY, DELAY_KEY);
    Delay(DELAY_KEY);
  }

  if ( g_remoteFlag&(BUTTON_HUMAN_LONG) ) {       // prepare to enter Engineer Mode
    g_remoteFlag = 0;
    engModeReady = TRUE;
    voicePlay(SWITCH_KEY, DELAY_KEY);
    Delay(DELAY_KEY);
  } 
  checkBaseMode(1);
  checkPowerOff(STATE_POWER_OFF);
}

void handler()
{
  switch(currentState) {
    case STATE_POWER_OFF:
      handlePowerOff();
      break;
    case STATE_INIT:
      handleInit();
      break;
    case STATE_READY_STER:
      handleReadyPlasmaSter();
      break;
    case STATE_STER:
      handlePlasmaSter();
      break;
    case STATE_STER_STOP:
      handlePlasmaSterStop();
      break;
    case STATE_READY_DIS:
      handleReadyDisinfect();
      break;
    case STATE_DIS:
      handleDisinfect();
      break;
    case STATE_DIS_STOP:
      handleDisinfectStop();
      break;
    case STATE_READY_ION:
      handleReadyIon();
      break;
    case STATE_ION:
      handleIon();
      break;
    case STATE_ION_STOP:
      handleIonStop();
      break;
    case STATE_CONSUMABLE_WARNING:
      handleConsumableWarning();
      break;
    case STATE_DESTRUCTION:
      handleDestruction();
      break;
    case STATE_PREPARE:
      handlePrepare();
      break;
    case STATE_ENGINEER_MODE:
      handleEngineerMode();
      break;
    case STATE_SETUP_MODE:
      handleSetup();
      break;
  }
}
