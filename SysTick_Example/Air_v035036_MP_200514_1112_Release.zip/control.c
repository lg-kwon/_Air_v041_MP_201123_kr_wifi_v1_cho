#include "control.h"
#include "relay.h"
#include "LED.h"

extern unsigned int fanBlinkOn;
extern unsigned int plasmaBlinkOnFlag;
extern unsigned int plasmaBlinkOffFlag;
extern unsigned char plasmaBlinkOn;

void control_relayAllOff()
{
  for(int i = 0; i < 8; i++)
    relayControl(i + 1, RELAY_OFF);
}

#ifdef  INCLUDE_OZONE_CONTROL
void reduceOzoneLevel()
{
  // Turn Off Ozone Source
  relayControl(RELAY_OZONE_LAMP, RELAY_OFF);
  relayControl(RELAY_PLASMA2, RELAY_OFF);
  relayControl(RELAY_PLASMA, RELAY_OFF);
  // Turn On OZone Destructor
  relayControl(RELAY_AC_UV, RELAY_ON);     //UV Lamp
  // Leave Fan1 & Fan2 ON
}  
#endif
//�ö�� ���
void control_sterOn()
{
#if 0
  if(plasmaInfo.pwr == 1)
  {
    relayControl(RELAY_OZONE_LAMP, RELAY_ON);       //OZONE Lamp
  }
  else if(plasmaInfo.pwr == 2)
  {
    relayControl(RELAY_OZONE_LAMP, RELAY_ON);       //OZONE Lamp    

    relayControl(RELAY_PLASMA, RELAY_ON);           //PLASMA1
  }
  else if(plasmaInfo.pwr == 3)
  {
    relayControl(RELAY_OZONE_LAMP, RELAY_ON);       //OZONE Lamp    

    relayControl(RELAY_PLASMA, RELAY_ON);           //PLASMA1
    relayControl(RELAY_PLASMA2, RELAY_ON);          //PLASMA2
  }
#endif
  switch (plasmaInfo.pwr) {                       // SJM 190808 fall-through
    case 3 :  relayControl(RELAY_PLASMA2, RELAY_ON);         //PLASMA2
    case 2 :  relayControl(RELAY_PLASMA, RELAY_ON);          //PLASMA1
    case 1 :  relayControl(RELAY_OZONE_LAMP, RELAY_ON);      //OZONE Lamp
        break;
  }
  relayControl(RELAY_AC_FAN1, RELAY_ON);          //FAN1  
  relayControl(RELAY_AC_FAN2, RELAY_ON);          //FAN2
  relayControl(RELAY_AC_UV, RELAY_OFF);     //UV Lamp
}

void control_sterOff()
{
    relayControl(RELAY_PLASMA2, RELAY_OFF);         //PLASMA2
    relayControl(RELAY_PLASMA, RELAY_OFF);          //PLASMA1
    relayControl(RELAY_OZONE_LAMP, RELAY_OFF);      //OZONE Lamp
    relayControl(RELAY_AC_UV, RELAY_OFF);     //UV Lamp
}

void normalPlasmaSter()
{
#if 1
      if (plasmaBlinkOnFlag == TRUE) {
        control_sterOff();
        //relayControl(RELAY_OZONE_LAMP, RELAY_OFF);       //OZONE Lamp
        RTC_TimeShow();
        printf(" Plasma --> OFF : %0.2d:%0.2d:%0.2d \n\r", RTC_TimeStructure.RTC_Hours, RTC_TimeStructure.RTC_Minutes, RTC_TimeStructure.RTC_Seconds);          
        plasmaBlinkOnFlag = FALSE;
      }
      if (plasmaBlinkOffFlag == TRUE) {
        control_sterOn();
        plasmaBlinkOffFlag = FALSE;
        RTC_TimeShow();
        printf(" Plasma --> ON : %0.2d:%0.2d:%0.2d \n\r", RTC_TimeStructure.RTC_Hours, RTC_TimeStructure.RTC_Minutes, RTC_TimeStructure.RTC_Seconds);
      }
#else
      if (plasmaBlinkOn) {
        control_sterOn();
//        plasmaBlinkOffFlag = FALSE;
        RTC_TimeShow();
        printf(" Plasma --> ON : %0.2d:%0.2d:%0.2d \n\r", RTC_TimeStructure.RTC_Hours, RTC_TimeStructure.RTC_Minutes, RTC_TimeStructure.RTC_Seconds);
      }
      else {
//      if (plasmaBlinkOnFlag == TRUE) {
        control_sterOff();
        //relayControl(RELAY_OZONE_LAMP, RELAY_OFF);       //OZONE Lamp
        RTC_TimeShow();
        printf(" Plasma --> OFF : %0.2d:%0.2d:%0.2d \n\r", RTC_TimeStructure.RTC_Hours, RTC_TimeStructure.RTC_Minutes, RTC_TimeStructure.RTC_Seconds);          
//        plasmaBlinkOnFlag = FALSE;
      }
#endif
}

#if 0     // SJM 190711 never used
void control_Blink_sterOff()
{
  if(plasmaInfo.pwr == 1)
  {
    relayControl(RELAY_OZONE_LAMP, RELAY_OFF);       //OZONE Lamp
  }
  else if(plasmaInfo.pwr == 2)
  {
    relayControl(RELAY_OZONE_LAMP, RELAY_OFF);       //OZONE Lamp    

    relayControl(RELAY_PLASMA, RELAY_OFF);           //PLASMA1
  }
  else if(plasmaInfo.pwr == 3)
  {
    relayControl(RELAY_OZONE_LAMP, RELAY_OFF);       //OZONE Lamp    

    relayControl(RELAY_PLASMA, RELAY_OFF);           //PLASMA1
    relayControl(RELAY_PLASMA2, RELAY_OFF);          //PLASMA2
  }
  
  relayControl(RELAY_AC_FAN1, RELAY_ON);          //FAN1  
  relayControl(RELAY_AC_FAN2, RELAY_ON);          //FAN2
  
}

//�ö�� ��� off
void control_sterOff()
{
  control_relayAllOff();
}

void control_disRelayOff()
{
  control_relayAllOff();
}

void control_IonOff()
{
  control_relayAllOff();
}
#endif

void control_disRelayOn()
{
  relayControl(RELAY_AC_FAN2, RELAY_ON);   //FAN2
  relayControl(RELAY_AC_UV, RELAY_ON);     //O3 UV
  relayControl(RELAY_RCI, RELAY_ON);       //RCI
#ifndef BACTERIA_FLOATING_TEST_RELEASE   
  relayControl(RELAY_SPI, RELAY_ON);       //SPI
#endif
#ifdef  STAND_TYPE_ENABLE
  if( fanBlinkOn == TRUE ) {  
    relayControl(RELAY_AC_FAN1, RELAY_ON);          //FAN1
    RTC_TimeShow();
    printf(" Fan --> ON : %0.2d:%0.2d:%0.2d \n\r", RTC_TimeStructure.RTC_Hours, RTC_TimeStructure.RTC_Minutes, RTC_TimeStructure.RTC_Seconds);
  }
#else
  relayControl(RELAY_AC_FAN1, RELAY_ON);          //FAN1  
#endif
}

void control_IonOn()
{
  relayControl(RELAY_AC_FAN2, RELAY_ON);   //FAN2
  //relayControl(RELAY_AC_UV, RELAY_ON);     //O3 UV
  relayControl(RELAY_SPI, RELAY_ON);       //SPI
  relayControl(RELAY_AC_FAN1, RELAY_ON);          //FAN1  
}

void control_relayDestruction()
{
  //2016.12.7 - BJ Kim requested : COMMENT
  //relayControl(RELAY_PLASMA, RELAY_ON);           //PLASMA1  
  relayControl(RELAY_AC_FAN2, RELAY_ON);   //FAN2
  // 2016.12.12 BJ Kim Requested Enable UV Lamp 
  relayControl(RELAY_AC_UV, RELAY_ON);     //UV Lamp
  relayControl(RELAY_AC_FAN1, RELAY_ON);   //FAN1  
}

void control_consumableCheckLed()
{
  ledControl(LED_PLASMA_FONT, LED_ON);
  ledControl(LED_DIS_FONT, LED_ON);
  ledControl(LED_ION_FONT, LED_ON);
  ledControl(LED_RESERVE_FONT, LED_ON);
  ledControl(LED_POWER_FONT, LED_ON);
  ledControl(LED_PID_FONT, LED_ON);

  ledControl(LED_POWER_SIG1, LED_ON);
  ledControl(LED_POWER_SIG2, LED_ON);
  ledControl(LED_MODE_SIG1, LED_ON);
  ledControl(LED_MODE_SIG2, LED_ON);
  ledControl(LED_SETTING_SIG1, LED_ON);
  ledControl(LED_SETTING_SIG2, LED_ON);
  ledControl(LED_PLASMA_ON, LED_OFF);
  ledControl(LED_DIS_ON, LED_OFF);
  ledControl(LED_ION_ON, LED_OFF);
  ledControl(LED_RESERVE_ON, LED_OFF);
  ledControl(LED_POWER_ON, LED_OFF);
  ledControl(LED_PID_ON, LED_OFF);
}

void control_sterStartLedOn()
{
  ledControl(LED_PLASMA_FONT, LED_ON);
  ledControl(LED_DIS_FONT, LED_ON);
  ledControl(LED_ION_FONT, LED_ON);
  ledControl(LED_RESERVE_FONT, LED_ON);
  ledControl(LED_POWER_FONT, LED_ON);
  ledControl(LED_PID_FONT, LED_ON);

  ledControl(LED_POWER_SIG1, LED_ON);
  ledControl(LED_POWER_SIG2, LED_ON);
  ledControl(LED_MODE_SIG1, LED_ON);
  ledControl(LED_MODE_SIG2, LED_ON);
  ledControl(LED_SETTING_SIG1, LED_ON);
  ledControl(LED_SETTING_SIG2, LED_ON);
  ledControl(LED_PLASMA_ON, LED_ON);
  ledControl(LED_DIS_ON, LED_OFF);
  ledControl(LED_ION_ON, LED_OFF);
  ledControl(LED_RESERVE_ON, LED_OFF);
  ledControl(LED_POWER_ON, LED_OFF);
  ledControl(LED_PID_ON, LED_OFF);
}

void control_sterStopLedOn()
{
  ledControl(LED_PLASMA_FONT, LED_ON);
  ledControl(LED_DIS_FONT, LED_ON);
  ledControl(LED_ION_FONT, LED_ON);
  ledControl(LED_RESERVE_FONT, LED_ON);
  ledControl(LED_POWER_FONT, LED_ON);
  ledControl(LED_PID_FONT, LED_ON);

  ledControl(LED_POWER_SIG1, LED_ON);
  ledControl(LED_POWER_SIG2, LED_ON);
  ledControl(LED_MODE_SIG1, LED_ON);
  ledControl(LED_MODE_SIG2, LED_ON);
  ledControl(LED_SETTING_SIG1, LED_ON);
  ledControl(LED_SETTING_SIG2, LED_ON);
  ledControl(LED_PLASMA_ON, LED_ON);
  ledControl(LED_DIS_ON, LED_OFF);
  ledControl(LED_ION_ON, LED_OFF);
  ledControl(LED_RESERVE_ON, LED_OFF);
  ledControl(LED_POWER_ON, LED_OFF);
  ledControl(LED_PID_ON, LED_OFF);
}

void control_disLed()
{
  ledControl(LED_PLASMA_FONT, LED_ON);
  ledControl(LED_DIS_FONT, LED_ON);
  ledControl(LED_ION_FONT, LED_ON);
  ledControl(LED_RESERVE_FONT, LED_ON);
  ledControl(LED_POWER_FONT, LED_ON);
  ledControl(LED_PID_FONT, LED_ON);

  ledControl(LED_POWER_SIG1, LED_ON);
  ledControl(LED_POWER_SIG2, LED_ON);
  ledControl(LED_MODE_SIG1, LED_ON);
  ledControl(LED_MODE_SIG2, LED_ON);
  ledControl(LED_SETTING_SIG1, LED_ON);
  ledControl(LED_SETTING_SIG2, LED_ON);
  ledControl(LED_PLASMA_ON, LED_OFF);
  ledControl(LED_DIS_ON, LED_ON);
  ledControl(LED_ION_ON, LED_OFF);
  ledControl(LED_RESERVE_ON, LED_OFF);
  ledControl(LED_POWER_ON, LED_OFF);
  ledControl(LED_PID_ON, LED_OFF);
}

void control_ionLed()
{
  ledControl(LED_PLASMA_FONT, LED_ON);
  ledControl(LED_DIS_FONT, LED_ON);
  ledControl(LED_ION_FONT, LED_ON);
  ledControl(LED_RESERVE_FONT, LED_ON);
  ledControl(LED_POWER_FONT, LED_ON);
  ledControl(LED_PID_FONT, LED_ON);

  ledControl(LED_POWER_SIG1, LED_ON);
  ledControl(LED_POWER_SIG2, LED_ON);
  ledControl(LED_MODE_SIG1, LED_ON);
  ledControl(LED_MODE_SIG2, LED_ON);
  ledControl(LED_SETTING_SIG1, LED_ON);
  ledControl(LED_SETTING_SIG2, LED_ON);
  ledControl(LED_PLASMA_ON, LED_OFF);
  ledControl(LED_DIS_ON, LED_OFF);
  ledControl(LED_ION_ON, LED_ON);
  ledControl(LED_RESERVE_ON, LED_OFF);
  ledControl(LED_POWER_ON, LED_OFF);
  ledControl(LED_PID_ON, LED_OFF);
}

void control_desLed()
{
  ledControl(LED_PLASMA_FONT, LED_ON);
  ledControl(LED_DIS_FONT, LED_ON);
  ledControl(LED_ION_FONT, LED_ON);
  ledControl(LED_RESERVE_FONT, LED_ON);
  ledControl(LED_POWER_FONT, LED_ON);
  ledControl(LED_PID_FONT, LED_ON);

  ledControl(LED_POWER_SIG1, LED_ON);
  ledControl(LED_POWER_SIG2, LED_ON);
  ledControl(LED_MODE_SIG1, LED_ON);
  ledControl(LED_MODE_SIG2, LED_ON);
  ledControl(LED_SETTING_SIG1, LED_ON);
  ledControl(LED_SETTING_SIG2, LED_ON);
  ledControl(LED_PLASMA_ON, LED_OFF);
  ledControl(LED_DIS_ON, LED_OFF);
  ledControl(LED_ION_ON, LED_OFF);
  ledControl(LED_RESERVE_ON, LED_OFF);
  ledControl(LED_POWER_ON, LED_OFF);
  ledControl(LED_PID_ON, LED_OFF);
}

void control_initLed()
{
  ledControl(LED_PLASMA_FONT, LED_ON);
  Delay(50);
  ledControl(LED_DIS_FONT, LED_ON);
  Delay(50);
  ledControl(LED_ION_FONT, LED_ON);
  Delay(50);
  ledControl(LED_RESERVE_FONT, LED_ON);
  Delay(50);
  ledControl(LED_POWER_FONT, LED_ON);
  Delay(50);
  ledControl(LED_PID_FONT, LED_ON);
  Delay(50);

  ledControl(LED_POWER_SIG1, LED_ON);
  Delay(50);
  ledControl(LED_POWER_SIG2, LED_ON);
  Delay(50);
  ledControl(LED_MODE_SIG1, LED_ON);
  Delay(50);
  ledControl(LED_MODE_SIG2, LED_ON);
  Delay(50);
  ledControl(LED_SETTING_SIG1, LED_ON);
  Delay(50);
  ledControl(LED_SETTING_SIG2, LED_ON);
  Delay(50);
  ledControl(LED_PLASMA_ON, LED_ON);
  Delay(50);
  ledControl(LED_DIS_ON, LED_ON);
  Delay(50);
  ledControl(LED_ION_ON, LED_ON);
  Delay(50);
  ledControl(LED_RESERVE_ON, LED_ON);
  Delay(50);
  ledControl(LED_POWER_ON, LED_ON);
  Delay(50);
  ledControl(LED_PID_ON, LED_ON);
  Delay(300);
  
  ledControl(LED_PLASMA_FONT, LED_OFF);
  Delay(50);
  ledControl(LED_DIS_FONT, LED_OFF);
  Delay(50);
  ledControl(LED_ION_FONT, LED_OFF);
  Delay(50);
  ledControl(LED_RESERVE_FONT, LED_OFF);
  Delay(50);
  ledControl(LED_POWER_FONT, LED_OFF);
  Delay(50);
  ledControl(LED_PID_FONT, LED_OFF);
  Delay(50);

  ledControl(LED_POWER_SIG1, LED_OFF);
  Delay(50);
  ledControl(LED_POWER_SIG2, LED_OFF);
  Delay(50);
  ledControl(LED_MODE_SIG1, LED_OFF);
  Delay(50);
  ledControl(LED_MODE_SIG2, LED_OFF);
  Delay(50);
  ledControl(LED_SETTING_SIG1, LED_OFF);
  Delay(50);
  ledControl(LED_SETTING_SIG2, LED_OFF);
  Delay(50);
  ledControl(LED_PLASMA_ON, LED_OFF);
  Delay(50);
  ledControl(LED_DIS_ON, LED_OFF);
  Delay(50);
  ledControl(LED_ION_ON, LED_OFF);
  Delay(50);
  ledControl(LED_RESERVE_ON, LED_OFF);
  Delay(50);
  ledControl(LED_POWER_ON, LED_OFF);
  Delay(50);
  ledControl(LED_PID_ON, LED_OFF);
  Delay(50);
}

void control_ledFont()
{
  ledAllOff();
  
  ledControl(LED_PLASMA_FONT, LED_ON);
  ledControl(LED_DIS_FONT, LED_ON);
  ledControl(LED_ION_FONT, LED_ON);
  ledControl(LED_RESERVE_FONT, LED_ON);
  ledControl(LED_POWER_FONT, LED_ON);
  ledControl(LED_PID_FONT, LED_ON);

  ledControl(LED_POWER_SIG1, LED_ON);
  ledControl(LED_POWER_SIG2, LED_ON);
  ledControl(LED_MODE_SIG1, LED_ON);
  ledControl(LED_MODE_SIG2, LED_ON);
  ledControl(LED_SETTING_SIG1, LED_ON);
  ledControl(LED_SETTING_SIG2, LED_ON);
}

void control_engineerLed()
{
  ledControl(LED_PLASMA_FONT, LED_ON);
  ledControl(LED_DIS_FONT, LED_ON);
  ledControl(LED_ION_FONT, LED_ON);
  ledControl(LED_RESERVE_FONT, LED_ON);
  ledControl(LED_POWER_FONT, LED_ON);
  ledControl(LED_PID_FONT, LED_ON);

  ledControl(LED_POWER_SIG1, LED_ON);
  ledControl(LED_POWER_SIG2, LED_ON);
  ledControl(LED_MODE_SIG1, LED_OFF);
  ledControl(LED_MODE_SIG2, LED_OFF);
  ledControl(LED_SETTING_SIG1, LED_OFF);
  ledControl(LED_SETTING_SIG2, LED_OFF);
  ledControl(LED_PLASMA_ON, LED_OFF);
  ledControl(LED_DIS_ON, LED_OFF);
  ledControl(LED_ION_ON, LED_OFF);
  ledControl(LED_RESERVE_ON, LED_OFF);
  ledControl(LED_POWER_ON, LED_OFF);
  ledControl(LED_PID_ON, LED_OFF);
}