#include "relay.h"

unsigned char ozoneLampOnFlag = FALSE;
unsigned char uvLampOnFlag = FALSE;
unsigned char rciOnFlag = FALSE;
unsigned char fan2OnFlag = FALSE;

void relayControlInit()
{
  GPIO_InitTypeDef  GPIO_InitStructure;
  
  /* Enable the GPIO_LED Clock */
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
  
  /* Configure the Relay pin */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_13;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  
    /* Configure the Relay pin */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
}
#if 0       // SJM 190715 never used!!!
void relayTest()
{
  /* Set PG6 and PG8 */
    GPIOA->BSRRL = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_13;
    GPIOB->BSRRL = GPIO_Pin_0 | GPIO_Pin_1;
    Delay(1000);
    /* Reset PG6 and PG8 */
    GPIOA->BSRRH = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_13;
    GPIOB->BSRRH = GPIO_Pin_0 | GPIO_Pin_1;
}
#endif
void relayControl(unsigned char relay, unsigned char onoff)
{
  switch(relay) {
#ifndef REPLACE_AC_FAN1_TO_PLASMA
  case RELAY_AC_FAN1:
    if(onoff == RELAY_ON) GPIOA->BSRRL = GPIO_Pin_3;
    else                  GPIOA->BSRRH = GPIO_Pin_3;
    break;
#endif
  case RELAY_OZONE_LAMP:
    ozoneLampOnFlag = onoff;
    if(onoff == RELAY_ON) GPIOA->BSRRL = GPIO_Pin_2;
    else                  GPIOA->BSRRH = GPIO_Pin_2;
    break;
  case RELAY_AC_UV:
    uvLampOnFlag = onoff;
    if(onoff == RELAY_ON) GPIOB->BSRRL = GPIO_Pin_0;
    else                  GPIOB->BSRRH = GPIO_Pin_0;
    break;
  case RELAY_AC_FAN2:
    fan2OnFlag = onoff;
    if(onoff == RELAY_ON) GPIOA->BSRRL = GPIO_Pin_13;
    else                  GPIOA->BSRRH = GPIO_Pin_13;
    break;
  case RELAY_PLASMA:
    if(onoff == RELAY_ON) GPIOB->BSRRL = GPIO_Pin_1;
    else                  GPIOB->BSRRH = GPIO_Pin_1;
    break;    
  case RELAY_PLASMA2:
    if(onoff == RELAY_ON) GPIOA->BSRRL = GPIO_Pin_0;
    else                  GPIOA->BSRRH = GPIO_Pin_0;
    break;
  case RELAY_SPI:
    if(onoff == RELAY_ON) GPIOA->BSRRL = GPIO_Pin_4;
    else                  GPIOA->BSRRH = GPIO_Pin_4;
    break;
  case RELAY_RCI:
    rciOnFlag = onoff;
    if(onoff == RELAY_ON) GPIOA->BSRRL = GPIO_Pin_1;
    else                  GPIOA->BSRRH = GPIO_Pin_1;
    break;
  }
}