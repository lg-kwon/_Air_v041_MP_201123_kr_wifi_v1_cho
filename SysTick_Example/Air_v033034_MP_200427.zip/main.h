/**
  ******************************************************************************
  * @file    SysTick/SysTick_Example/main.h 
  * @author  
  * @version V1.0.0
  * @date    30-September-2011
  * @brief   Header for main.c module
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 HealthWell Medical</center></h2>
  ******************************************************************************  
  */ 

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#define FALSE                       0
#define TRUE                        1

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "stm324xg_eval.h"
#include "Peripheral.h"
#include "24LC512.h"
#include "Key.h"
#include "relay.h"
#include "RTC.h"
#include "LED.h"
#include "remote.h"
#include "isd1760.h"
#include "pir.h"
#include "eeprom.h"
//#include "handler.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//#define STAND_TYPE_ENABLE
//#define MEDICA_EXPO

#define ADD_REMOTE_OZONE_SENSOR
//#define OZONE_DEPENDENT_DESTRUCTION
//#define BACTERIA_FLOATING_TEST_RELEASE
#define CHECK_OZONE_LIMIT
//#define REPLACE_AC_FAN1_TO_PLASMA

/********************** Modified by SJM ****************************************************/
#define SJM_DEBUG
#define INCLUDE_REMOTE_ACK            // SJM 190620 add key sound for acknowledge
//#define ENGLISH_VOICE                 // SJM 190621
#define PREPARATION_TIME         30   // SJM 190710 shorten for Test. original was 30sec.
#define USE_119SP_REMOTE              // SJM 190716 use RemoCon for OKC-119SP together.
#define UNIFY_CONTINUE_OP             // SJM 190724 unify continue operation
#define NEW_VOICE                     // SJM 190807 replace new voice
//#define USE_100PPB_SENSOR             // SJM 190812 use 100ppb sensor instead of 250ppb
#define USE_250PPB_SENSOR

#define INCLUDE_OZONE_CONTROL         // SJM 190808 add to control ozone concentration
#ifdef  INCLUDE_OZONE_CONTROL
  #ifdef USE_250PPB_SENSOR
    #define OZONE_SAFE_LEVEL          60  // SJM 190808 add to control ozone concentration
    #define OZONE_RISK_LEVEL          90  // SJM 190808 add to control ozone concentration
//    #define OZONE_OVER_LIMIT          80  // SJM 190812 ozone over time, 80*0.5 = 40sec.
    #define OZONE_OVER_LIMIT          120  // SJM 190812 ozone over time, 120*0.5 = 60sec.
  #else 
    #define OZONE_SAFE_LEVEL          40  // SJM 190808 add to control ozone concentration
    #define OZONE_RISK_LEVEL          60  // SJM 190808 add to control ozone concentration
    #define OZONE_OVER_LIMIT          60  // SJM 190812 ozone over time, 60*0.5 = 30sec.
  #endif // USE_250PPB_SENSOR
#endif

#define INCLUDE_RETURN_TO_CONTINUOUS_MODE // SJM 191018 return to continuous operation
                                          //        after completing the reserved plasma sterilization
                                          //        according to DHKwon's request from ver 29-30
//#define REDUCE_TIME_TO_TEST               // SJM 191018 for test-only
#define VOICE_FIRST                       // SJM 200421 play voice before relay control due to noise

#define BASE_VERSION              33      // SJM 200421 play voice before relay control due to noise 
#ifdef  ENGLISH_VOICE
  #define SW_VERSION              (BASE_VERSION+1)
#else
  #define SW_VERSION              (BASE_VERSION)
#endif  

#define SET_TIME                  0
#define SET_PLASMA_RESERVATION    1

/* Handler Types  ------------------------------------------------------------*/
#define STATE_READY_STER            1
#define STATE_READY_DIS             2
#define STATE_READY_ION             3
#define STATE_INIT                  4
#define STATE_STER                  5
#define STATE_DIS                   6
#define STATE_ION                   7
#define STATE_POWER_OFF             8
#define STATE_STER_STOP             9
#define STATE_DIS_STOP              10
#define STATE_ION_STOP              11
#define STATE_CONSUMABLE_WARNING    12
#define STATE_DESTRUCTION           13
#define STATE_PREPARE               14
#define STATE_SETUP_MODE            15
#define STATE_ENGINEER_MODE         16

#define LAST_STATE                  16      // SJM 190703 it should revised when new State added.
#define DEFAULT_STATE               STATE_READY_DIS   // SJM 190723 for prevState

#define PLASMA_MODE_START           1
#define PLASMA_MODE_READY           2
#define PLASMA_MODE_STOP            3
#define PLASMA_MODE_RESERVE         4

/* Exported types ------------------------------------------------------------*/
#if 0     // SJM 190723 commented as it is not used
  #define MODE_STER                   1
  #define MODE_DIS                    2
  #define MODE_ION                    3

  #define SETTING_NONE                0
  #define SETTING_RESERVE             1
  #define SETTING_POWER               2
  #define SETTING_PID                 3
#endif


/* Consumables Define ------------------------------------------------------------*/
/* 2016.12.13. DH Kwon Requested  */
//#define CHANGE_OZONE_LAMP     4000
//#define CHANGE_UV_LAMP        4000
//#define CHANGE_FILTER         4000
// SJM 190723 commented 
//  #define CHANGE_OZONE_LAMP     25000
//  #define CHANGE_UV_LAMP        8000

#define CHANGE_OZONE_LAMP    480000            // SJM 190722 OzoneLamp  8000Hx60M
#define CHANGE_UV_LAMP       480000            // SJM 190722 UvLamp     8000Hx60M
#define CHANGE_RCI_CELL     1500000            // SJM 190722 RCIcell   25000Hx60M
#define CHANGE_FILTER        600000            // SJM 190723 Filter    10000Hx60M (DH Kwon request)

/*2016.12.13. DH Kwon Requested
#define WARNING_NUMBER        3
*/
//#define WARNING_NUMBER        3           // SJM 190722 add RCIcell as a consumable
#define WARNING_NUMBER        4           // SJM 190723 add Filter as a consumable again

#define WARNING_OZONE_LAMP    0x0001
#define WARNING_UV_LAMP       0x0002
#define WARNING_RCI_CELL    0x0004
#define WARNING_FILTER      0x0008        // SJM 190723 add Filter as a consumable again as DH Kwon Requested
//#define WARNING_FILTER        0x0004        2016.12.13. DH Kwon Requested

#ifdef  MEDICA_EXPO
  #define PLASMA_BLINK_ON_TIME    10    // 10sec
  #define PLASMA_BLINK_OFF_TIME   120   // 120sec
#else
  #define PLASMA_BLINK_ON_TIME    30    //10sec
  #define PLASMA_BLINK_OFF_TIME   30    //sec
#endif

#ifdef  STAND_TYPE_ENABLE
  #define FAN_BLINK_ON_TIME       300   // 5min
  #define FAN_BLINK_OFF_TIME      60    // 1min
#endif

typedef struct {
  unsigned char pidOn;
  unsigned char pwr;
  unsigned char rsvOn;
  unsigned char isScheduled;        // SJM 190724 added to replace 'Mode'. 1=scheduled.
  int rsvTime;
//  unsigned int modeSelect;        // SJM 190715 useless??
  unsigned int blinkOnTimer;
  unsigned int blinkOffTimer;
  unsigned char blinkOnFlag;
  unsigned char blinkOffFlag;
//  unsigned int Mode;              // SJM 190724 replaced by 'isScheduled
  unsigned int plasmaOneSec;
  unsigned int plasmaTimer;
#ifndef UNIFY_CONTINYE_OP
  unsigned char continuation;
#endif
}PLASMAINFO;

typedef struct {
  unsigned int blinkOnTimer;
  unsigned int blinkOffTimer;
  unsigned char blinkOnFlag;
  unsigned char blinkOffFlag;
  unsigned int disOneSec;
  unsigned int disTimer;
#ifndef UNIFY_CONTINYE_OP
  unsigned char continuation;
#endif
}DISINFO;

typedef struct {
  unsigned int blinkOnTimer;
  unsigned int blinkOffTimer;
  unsigned char blinkOnFlag;
  unsigned char blinkOffFlag;
  unsigned int ionOneSec;
  unsigned int ionTimer;
#ifndef UNIFY_CONTINYE_OP
  unsigned char continuation;
#endif
}IONINFO;

typedef struct {
  unsigned int rciOperatingMin;           //minute
//  unsigned int totalOperatingMin;         //Minite
  unsigned int uvLampCountMin;            //Minite
  unsigned int ozoneLampCountMin;         //Minite
  unsigned int filterCountMin;            //Minite
  unsigned int prevState;
  unsigned int blinkOnTimer;
  unsigned int blinkOffTimer;
  unsigned char blinkOnFlag;
  unsigned char blinkOffFlag;
//  unsigned int disOneSec;             never used.
  PLASMAINFO plasmaInfo;  
}SYSTEMINFO;

#define     UpgradeEEP           61110
#define     UpgradeEEP2          31110
#define     UpgradeEEPdata       0xa55a

#ifdef  CHECK_OZONE_LIMIT
    #define     CheckRoomTempEEP       61130
    #define     CheckRoomTempEEP2      31130    
    #define     CheckOZLimitEEPData   0xa53a
#endif
    
/* Global define ------------------------------------------------------------*/
#define MAX_RX_BUFFER             50
#define SYSTEM_SIZE               sizeof(SYSTEMINFO)
#define ONESEC                    1000
//#define FIVESEC                   5000      SJM190724 currently NoUse
#define MAX_SIZE_PRINT            500

extern unsigned int g_keyFlag;

extern SYSTEMINFO sysConfig;
extern PLASMAINFO plasmaInfo;
extern DISINFO disInfo;
extern IONINFO ionInfo;

extern RTC_TimeTypeDef RTC_TimeStructure;
extern RTC_InitTypeDef RTC_InitStructure;
extern RTC_DateTypeDef RTC_DateStructure;
extern RTC_TimeTypeDef  RTC_TimeStampStructure;
extern RTC_DateTypeDef  RTC_TimeStampDateStructure;

extern unsigned char g_volume;        // SJM 190716 added by SJM. originally it was 15(constant)

/* Exported constants --------------------------------------------------------*/
#ifdef  NEW_VOICE
  //======================================================================================================================
  // Voice Track(��������� Ʈ����ȣ)
  //======================================================================================================================
  #define VOICE_POWERON_START                 0x10		
  #define VOICE_POWERON_END                   0x2D		
  #define VOICE_POWER_OFF_START               0x2E           
  #define VOICE_POWER_OFF_END                 0x3B
  #define VOICE_KEY_START                     0x3C          
  #define VOICE_KEY_END                       0x40

  #define DELAY_POWERON                       3643        
  #define DELAY_POWER_OFF                     1654
  #define DELAY_KEY                           523

#ifdef ENGLISH_VOICE
  //======================================================================================================================
  // Voice Track(��������� Ʈ����ȣ)
  //======================================================================================================================
  #define VOICE_PLASMA_MODE_START             0x41
  #define VOICE_PLASMA_MODE_END               0x49

  #define VOICE_DISINFECT_MODE_START          0x4A
  #define VOICE_DISINFECT_MODE_END            0x53

  #define VOICE_ANION_MODE_START              0x54
  #define VOICE_ANION_MODE_END                0x5C

  #define VOICE_SETUP_MODE_START              0x5D
  #define VOICE_SETUP_MODE_END                0x65

  #define VOICE_PLASMA_START_START            0x66           
  #define VOICE_PLASMA_START_END              0x75

  #define VOICE_PREPARE_START                 0x76           
  #define VOICE_PREPARE_END                   0x7F   

  #define VOICE_PLASMA_STOP_START             0x80        
  #define VOICE_PLASMA_STOP_END               0x8F

  #define VOICE_STERILIZATION_START_START     0x90           
  #define VOICE_STERILIZATION_START_END       0x9A           

  #define VOICE_STERILIZATION_STOP_START      0x9B           
  #define VOICE_STERILIZATION_STOP_END        0xA6           

  #define VOICE_ION_START_START               0xA7           
  #define VOICE_ION_START_END                 0xB3

  #define VOICE_ION_STOP_START                0xB4          
  #define VOICE_ION_STOP_END                  0xC0

  #define VOICE_DESTRUCTION_START_START       0xC1       
  #define VOICE_DESTRUCTION_START_END         0xD0

  #define VOICE_DESTRUCTION_STOP_START        0xD1
  #define VOICE_DESTRUCTION_STOP_END          0xE0

  #define VOICE_CONSUMABLE_CHECK_START        0xE1
  #define VOICE_CONSUMABLE_CHECK_END          0xEF

  #define VOICE_PIR_DETECT_START              0xF0           
  #define VOICE_PIR_DETECT_END                0xFC

  #define VOICE_OZONE_DETECT_START            0xFD
  #define VOICE_OZONE_DETECT_END              0x11F

  #define VOICE_ENGINEER_MODE_START           0x120
  #define VOICE_ENGINEER_MODE_END             0x128

  //======================================================================================================================
  // Voice Track Delay(��������� �����ð�)
  //======================================================================================================================
  #define DELAY_PLASMA_MODE                   1006
  #define DELAY_DISINFECT_MODE                1204
  #define DELAY_ANION_MODE                    1008
  #define DELAY_SETUP_MODE                    1006
  #define DELAY_PLASMA_START                  1882
  #define DELAY_PREPARE                       1236
  #define DELAY_PLASMA_STOP                   1901
  #define DELAY_STER_START                    1338        
  #define DELAY_STER_STOP                     1408
  #define DELAY_ION_START                     1535
  #define DELAY_ION_STOP                      1501
  #define DELAY_DESTRUCTION_START             1970
  #define DELAY_DESTRUCTION_STOP              1962
  #define DELAY_CONSUMABLE_CHECK              1852
  #define DELAY_PIR_DETECT                    1592
  #define DELAY_OZONE_DETECT                  4286
  #define DELAY_ENGINEER_MODE                 1101
#else // KOREAN_VOICE
  //======================================================================================================================
  // Voice Track(��������� Ʈ����ȣ)
  //======================================================================================================================
  #define VOICE_PLASMA_MODE_START             0x41
  #define VOICE_PLASMA_MODE_END               0x49

  #define VOICE_DISINFECT_MODE_START          0x4A
  #define VOICE_DISINFECT_MODE_END            0x55

  #define VOICE_ANION_MODE_START              0x56
  #define VOICE_ANION_MODE_END                0x5E

  #define VOICE_SETUP_MODE_START              0x5F
  #define VOICE_SETUP_MODE_END                0x67

  #define VOICE_PLASMA_START_START            0x68           
  #define VOICE_PLASMA_START_END              0x78

  #define VOICE_PREPARE_START                 0x79           
  #define VOICE_PREPARE_END                   0x85   

  #define VOICE_PLASMA_STOP_START             0x86        
  #define VOICE_PLASMA_STOP_END               0x97

  #define VOICE_STERILIZATION_START_START     0x98           
  #define VOICE_STERILIZATION_START_END       0xA4           

  #define VOICE_STERILIZATION_STOP_START      0xA5           
  #define VOICE_STERILIZATION_STOP_END        0xB5           

  #define VOICE_ION_START_START               0xB6           
  #define VOICE_ION_START_END                 0xC5

  #define VOICE_ION_STOP_START                0xC6          
  #define VOICE_ION_STOP_END                  0xD6

  #define VOICE_DESTRUCTION_START_START       0xD7       
  #define VOICE_DESTRUCTION_START_END         0xE7

  #define VOICE_DESTRUCTION_STOP_START        0xE8
  #define VOICE_DESTRUCTION_STOP_END          0xF8

  #define VOICE_CONSUMABLE_CHECK_START        0xF9
  #define VOICE_CONSUMABLE_CHECK_END          0x10A

  #define VOICE_PIR_DETECT_START              0x10B           
  #define VOICE_PIR_DETECT_END                0x118

  #define VOICE_OZONE_DETECT_START            0x119
  #define VOICE_OZONE_DETECT_END              0x137

  #define VOICE_ENGINEER_MODE_START           0x138
  #define VOICE_ENGINEER_MODE_END             0x140

  //======================================================================================================================
  // Voice Track Delay(��������� �����ð�)
  //======================================================================================================================
  #define DELAY_PLASMA_MODE                   1071
  #define DELAY_DISINFECT_MODE                1467
  #define DELAY_ANION_MODE                    1075
  #define DELAY_SETUP_MODE                    1052
  #define DELAY_PLASMA_START                  2120
  #define DELAY_PREPARE                       1612
  #define DELAY_PLASMA_STOP                   2221
  #define DELAY_STER_START                    1563        
  #define DELAY_STER_STOP                     2036
  #define DELAY_ION_START                     1878
  #define DELAY_ION_STOP                      2026
  #define DELAY_DESTRUCTION_START             2074
  #define DELAY_DESTRUCTION_STOP              2033
  #define DELAY_CONSUMABLE_CHECK              2135
  #define DELAY_PIR_DETECT                    1733
  #define DELAY_OZONE_DETECT                  3796
  #define DELAY_ENGINEER_MODE                 1092
#endif // ENGLISH_VOICE
//======================================================================================================================
// Voice Switch
//======================================================================================================================
#define SWITCH_POWER_ON                     1
#define SWITCH_POWER_OFF                    2
#define SWITCH_KEY                          3
#define SWITCH_PLASMA_MODE                  4
#define SWITCH_DISINFECT_MODE               5
#define SWITCH_ANION_MODE                   6
#define SWITCH_SETUP_MODE                   7
#define SWITCH_PLASMA_START                 8
#define SWITCH_PREPARE                      9
#define SWITCH_PLASMA_STOP                  10
#define SWITCH_STERILIZATION_START          11
#define SWITCH_STERILIZATION_STOP           12
#define SWITCH_ION_START                    13
#define SWITCH_ION_STOP                     14
#define SWITCH_DESTRUCTION_START            15
#define SWITCH_DESTRUCTION_STOP             16
#define SWITCH_CONSUMABLE_CHECK             17
#define SWITCH_PIR_DETECT                   18
#define SWITCH_OZONE_DETECT                 19
#define SWITCH_ENGINEER_MODE                20
#else // NEW_VOICE
#ifdef ENGLISH_VOICE
  //======================================================================================================================
  // Voice Track(��������� Ʈ����ȣ)
  //======================================================================================================================
  #define VOICE_POWERON_START                 0x10		
  #define VOICE_POWERON_END                   0x2D		

  #define VOICE_STERILIZATION_START_START     0x2E           
  #define VOICE_STERILIZATION_START_END       0x3B           

  #define VOICE_STERILIZATION_STOP_START      0x3C           
  #define VOICE_STERILIZATION_STOP_END        0x48           

  #define VOICE_PREPARE_START                 0x49           
  #define VOICE_PREPARE_END                   0x68   

  #define VOICE_ION_START_START               0x69           
  #define VOICE_ION_START_END                 0x73

  #define VOICE_PLASMA_START_START            0x74           
  #define VOICE_PLASMA_START_END              0x83

  #define VOICE_PIR_DETECT_START              0x84           
  #define VOICE_PIR_DETECT_END                0x8F

  #define VOICE_POWER_OFF_START               0x90           
  #define VOICE_POWER_OFF_END                 0x9D

  #define VOICE_KEY_START                     0x9E          
  #define VOICE_KEY_END                       0xA2

  #define VOICE_ION_STOP_START                0xA3          
  #define VOICE_ION_STOP_END                  0xB2

  #define VOICE_PLASMA_STOP_START             0xB3        
  #define VOICE_PLASMA_STOP_END               0xC2

  #define VOICE_DESTRUCTION_START_START       0xC3       
  #define VOICE_DESTRUCTION_START_END         0xD3

  #define VOICE_DESTRUCTION_ERROR_START       0xD4
  #define VOICE_DESTRUCTION_ERROR_END         0xDE

  #define VOICE_DESTRUCTION_STOP_START        0xDF
  #define VOICE_DESTRUCTION_STOP_END          0xF1

  #define VOICE_OZONE_TIME_SET_START          0xF2
  #define VOICE_OZONE_TIME_SET_END            0xFF

  #define VOICE_OZONE_DETECT_START            0x100
  #define VOICE_OZONE_DETECT_END              0x122

  #define VOICE_PLASMA_MODE_START             0x123
  #define VOICE_PLASMA_MODE_END               0x12c

  #define VOICE_ANION_MODE_START              0x12d
  #define VOICE_ANION_MODE_END                0x135

  #define VOICE_DISINFECT_MODE_START          0x136
  #define VOICE_DISINFECT_MODE_END            0x13f

  #define VOICE_SETUP_MODE_START              0x140
  #define VOICE_SETUP_MODE_END                0x148

  //======================================================================================================================
  // Voice Track Delay(��������� �����ð�)
  //======================================================================================================================
  #define DELAY_POWERON                       3643        
  #define DELAY_STER_START                    1629        
  #define DELAY_STER_STOP                     1590
  #define DELAY_PREPARE                       3959
  #define DELAY_ION_START                     1253
  #define DELAY_PLASMA_START                  1909
  #define DELAY_PIR_DETECT                    1455
  #define DELAY_POWER_OFF                     1654
  #define DELAY_KEY                           523
  #define DELAY_ION_STOP                      1998
  #define DELAY_PLASMA_STOP                   1886
  #define DELAY_DESTRUCTION_START             2061
  #define DELAY_DESTRUCTION_ERROR             1347
  #define DELAY_DESTRUCTION_STOP              2268
  #define DELAY_OZONE_TIME_SET                1678
  #define DELAY_OZONE_DETECT                  4355
  #define DELAY_PLASMA_MODE                   1212
  #define DELAY_ANION_MODE                    1005
  #define DELAY_DISINFECT_MODE                1150
  #define DELAY_SETUP_MODE                    1007

#else // KOREAN_VOICE
  //======================================================================================================================
  // Voice Track(��������� Ʈ����ȣ)
  //======================================================================================================================
  #define VOICE_POWERON_START                 0x10		
  #define VOICE_POWERON_END                   0x2D		

  #define VOICE_STERILIZATION_START_START     0x2E           
  #define VOICE_STERILIZATION_START_END       0x3C           

  #define VOICE_STERILIZATION_STOP_START      0x3D           
  #define VOICE_STERILIZATION_STOP_END        0x4B           

  #define VOICE_PREPARE_START                 0x4C           
  #define VOICE_PREPARE_END                   0x6F   

  #define VOICE_ION_START_START               0x70           
  #define VOICE_ION_START_END                 0x7E

  #define VOICE_PLASMA_START_START            0x7F           
  #define VOICE_PLASMA_START_END              0x8E

  #define VOICE_PIR_DETECT_START              0x8F           
  #define VOICE_PIR_DETECT_END                0x9C

  #define VOICE_POWER_OFF_START               0x9D           
  #define VOICE_POWER_OFF_END                 0xAA

  #define VOICE_KEY_START                     0xAB          
  #define VOICE_KEY_END                       0xAF

  #define VOICE_ION_STOP_START                0xB0          
  #define VOICE_ION_STOP_END                  0xBD

  #define VOICE_PLASMA_STOP_START             0xBE        
  #define VOICE_PLASMA_STOP_END               0xCD

  #define VOICE_DESTRUCTION_START_START       0xCE       
  #define VOICE_DESTRUCTION_START_END         0xDC

  #define VOICE_DESTRUCTION_ERROR_START       0xDD
  #define VOICE_DESTRUCTION_ERROR_END         0xEA

  #define VOICE_DESTRUCTION_STOP_START        0xEB
  #define VOICE_DESTRUCTION_STOP_END          0xF9

  #define VOICE_OZONE_TIME_SET_START          0xFA
  #define VOICE_OZONE_TIME_SET_END            0x10B

  #define VOICE_OZONE_DETECT_START            0x10C
  #define VOICE_OZONE_DETECT_END              0x12E

  //======================================================================================================================
  // Voice Track Delay(��������� �����ð�)
  //======================================================================================================================
  #define DELAY_POWERON                       3643        
  #define DELAY_STER_START                    1840        
  #define DELAY_STER_STOP                     1840
  #define DELAY_PREPARE                       4443
  #define DELAY_ION_START                     1837
  #define DELAY_PLASMA_START                  1881
  #define DELAY_PIR_DETECT                    1689
  #define DELAY_POWER_OFF                     1654
  #define DELAY_KEY                           523
  #define DELAY_ION_STOP                      1734
  #define DELAY_PLASMA_STOP                   1964
  #define DELAY_DESTRUCTION_START             1769
  #define DELAY_DESTRUCTION_ERROR             1710
  #define DELAY_DESTRUCTION_STOP              1779
  #define DELAY_OZONE_TIME_SET                2136
  #define DELAY_OZONE_DETECT                  5000
#endif // ENGLISH_VOICE
//======================================================================================================================
// Voice Switch
//======================================================================================================================
#define SWITCH_POWER_ON                     1
#define SWITCH_STERILIZATION_START          2
#define SWITCH_STERILIZATION_STOP           3
#define SWITCH_PREPARE                      4
#define SWITCH_ION_START                    5
#define SWITCH_PLASMA_START                 6
#define SWITCH_PIR_DETECT                   7
#define SWITCH_POWER_OFF                    8
#define SWITCH_KEY                          9
#define SWITCH_ION_STOP                     10
#define SWITCH_PLASMA_STOP                  11
#define SWITCH_DESTRUCTION_START            12
#define SWITCH_DESTRUCTION_ERROR            13
#define SWITCH_DESTRUCTION_STOP             14
#define SWITCH_OZONE_TIME_SET               15
#define SWITCH_OZONE_DETECT                 16
#ifdef  ENGLISH_VOICE
  #define SWITCH_PLASMA_MODE                17
  #define SWITCH_ANION_MODE                 18
  #define SWITCH_DISINFECT_MODE             19
  #define SWITCH_SETUP_MODE                 20
#endif
#endif  // NEW_VOICE

/* Exported macro ------------------------------------------------------------*/
#define VOICE_PLAY(track)                   \
        do                                  \
        {                                   \
            ISD1760_setPlay(                \
                ##track##_START,            \
                ##track##_END,              \
                g_volume);                        \
        } while(0);                         \
//                15);                        \


#define VOICE_OFF()                         \
        do                                  \
        {                                   \
        } while(0);
/* Exported functions ------------------------------------------------------- */

void TimingDelay_Decrement(void);
uint32_t sEE_TIMEOUT_UserCallback(void);
void Delay(__IO uint32_t nTime);
extern void voicePortInit();
#endif /* __MAIN_H */

/******************* (C) COPYRIGHT 2011 HealthWell *****END OF FILE****/
