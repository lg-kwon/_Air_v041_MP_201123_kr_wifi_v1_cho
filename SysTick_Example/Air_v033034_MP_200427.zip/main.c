/**
  * 0.5v - �ö�� ��忡�� ������ ������ ���� ��.(���� ��忡 �°�)
  *        ���� ���� �߰�
  * 0.6v - �ö�� ��忡�� ��ü���� ���� ����.
  *        ��ü ���� �߿��� ���� ���� �۵� ����.
  *        �ö�� ��忡�� ���� ���� ���� ����(0~3 -> 0~2)
  * 0.7v - ����� ��忡�� UV Lamp�� ���۽�Ŵ
  *        �ö�� ��忡�� �⺻ ���⸦ 1�� ����, ���� ����(0~2 -> 1~3)
  * 0.8v - �ö�� ��� ���� �� ���� ��ư�� ������ ���� ���Ⱑ ǥ�� ��.
  *        �Ҹ�ǰ ��ü Warningǥ�� �� Ȯ�� ��ư�� ������ Main���� �Ѿ� ��.
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/** @addtogroup STM32F4xx_StdPeriph_Examples
  * @{
  */

/** @addtogroup SysTick_Example
  * @{
  */ 

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
unsigned int testLedBlink = FALSE;
unsigned char rx_buffer[MAX_RX_BUFFER];
unsigned char rx_head;
unsigned char rx_tail;
unsigned char setRTCFlag;
unsigned int m_remoteState;
extern unsigned char pBuf[];
extern unsigned int pPointer;
unsigned int oldPpointer;
unsigned char printfTest;
unsigned int segBlinkOnTime;

unsigned int currentState, isFirstEntrance;   // SJM 190711 never used , isReadyEntrance;
unsigned char pidDetect;
unsigned int oneSecFlag;
unsigned int g_remoteFlag;

SYSTEMINFO sysConfig;
PLASMAINFO plasmaInfo;
DISINFO disInfo;
IONINFO ionInfo;

GPIO_InitTypeDef GPIO_InitStructure;
static __IO uint32_t TimingDelay;
  
/* Private function prototypes -----------------------------------------------*/
void Delay(__IO uint32_t nTime);

/* Private functions ---------------------------------------------------------*/
extern void GetUARTData();
extern void handler();
extern void changeState(unsigned char state, unsigned char write);
extern void voicePlay(unsigned int voice, unsigned int delay);

/**
  * @brief   Main program
  * @param  None
  * @retval None
  */
#ifdef  INCLUDE_RETURN_TO_CONTINUOUS_MODE
extern unsigned char returnToContinuousOperation;
extern unsigned char prevOperation;
extern unsigned char continueOperation;
#endif

int main(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure;
  
  /* Enable the GPIO_LED Clock */
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
  
  /* Configure the GPIO_LED pin */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);

  if (SysTick_Config(SystemCoreClock / 1000)) { 
    /* Capture error */ 
    while (1);
  }

  TIM_Config();
  remoteTimerInit();
  remoteInit();
  Uart_init();
  pirInit();
  sEE_Init();    //24LC512 Init
  relayControlInit();   //relay port Init
  keyPortInit();
  ledPortInit();
  ISD1760_init();
  voicePortInit(); //voice Port init

  ozoneSensorInit();
  ADC_SoftwareStartConv(ADC1);
  
  GPIOB->BSRRL = GPIO_Pin_8;
  Delay(10);
  
  rtc_check();
  rtc_init();
  
  printfTest = FALSE;
#ifndef STAND_TYPE_ENABLE
  printf("\r\n  Wall Type  : HPA-130W\r\n");
#else
  printf("\r\n  Stand Type : HPA-85S\r\n");
#endif
  printf("\r\n   Ver %d\r\n", SW_VERSION);
  printf("\r\n  HealthWell Medical Inc.\r\n");
  
  currentState = STATE_POWER_OFF;
  isFirstEntrance = TRUE;

  //system loading
  systemRead();
  
  while (1) {
    GetUARTData();
    handler();
    if (g_keyFlag) {
      if ((g_keyFlag&KEY_UPGRADE)==KEY_UPGRADE) {
        voicePlay(SWITCH_KEY, DELAY_KEY);
        Delay(DELAY_KEY);
        UpgradeEEPWrite(UpgradeEEPdata);
        NVIC_SystemReset();
      }
      g_keyFlag = 0;
    }
    if(testLedBlink == TRUE) {
      testLedBlink = FALSE;
      GPIOB->ODR ^= GPIO_Pin_8;
      //GPIOA->ODR ^= GPIO_Pin_14;
    }
         // SJM 190704 ???
//    if(pidDetect == TRUE) pidDetect = FALSE;
    if (currentState != STATE_POWER_OFF)
      ledControl(LED_PID_FONT,pidDetect);
    //���� ����.
#ifndef INCLUDE_RETURN_TO_CONTINUOUS_MODE
    if(currentState == STATE_POWER_OFF || currentState == STATE_READY_STER ||
       currentState == STATE_READY_ION || currentState == STATE_READY_DIS ) {
#else
    if(currentState == STATE_POWER_OFF || currentState == STATE_READY_STER || currentState == STATE_STER_STOP ||
       currentState == STATE_READY_ION || currentState == STATE_ION_STOP || 
       currentState == STATE_READY_DIS || currentState == STATE_DIS_STOP ||
       (((currentState==STATE_DIS)||(currentState==STATE_ION))&&(continueOperation))) {
#endif
      //1�ʸ���.
      if(oneSecFlag == TRUE) {
          oneSecFlag = FALSE;
          RTC_GetTime(RTC_Format_BIN, &RTC_TimeStructure);
          (void)RTC->DR;
          if(plasmaInfo.rsvOn == TRUE) {
#if 0     // SJM 190724 reservation can be set only 'Hour'
            if(RTC_TimeStructure.RTC_Hours == plasmaInfo.rsvTime && 
               RTC_TimeStructure.RTC_Minutes == 0 && 
               RTC_TimeStructure.RTC_Seconds == 0) {
              currentState = STATE_STER;
              isFirstEntrance = TRUE;
              plasmaInfo.Mode = PLASMA_MODE_RESERVE;
            }
#else     // SJM 190928 �ð��� check�ϸ� �߰��� �ߴ��ص� 1�ð������� ��� �ݺ��� ����� ����.
          // ==> �ѹ� ���۽�Ų ���Ŀ��� �ٽ� ������ �ȵ�.
            if ((RTC_TimeStructure.RTC_Hours == plasmaInfo.rsvTime)&&
                (RTC_TimeStructure.RTC_Minutes == 0)&&(RTC_TimeStructure.RTC_Seconds == 0)) {
  #ifdef  INCLUDE_RETURN_TO_CONTINUOUS_MODE
//              if (((currentState==STATE_DIS)||(currentState==STATE_ION))&&(continueOperation))
//                returnToContinuousOperation = TRUE;
//              else  returnToContinuousOperation = FALSE;
              switch (currentState) {
                case STATE_DIS       :  if (continueOperation) {
                                          returnToContinuousOperation = TRUE;
                                          prevOperation = STATE_DIS;
                                        }
                                        else {
                                          returnToContinuousOperation = FALSE;
                                          prevOperation = STATE_READY_DIS;
                                        }
                                        break;
                case STATE_ION       :  if (continueOperation) {
                                          returnToContinuousOperation = TRUE;
                                          prevOperation = STATE_ION;
                                        }
                                        else {
                                          returnToContinuousOperation = FALSE;
                                          prevOperation = STATE_READY_ION;
                                        }
                                        break;
                case STATE_INIT      :  // fall-through
                case STATE_POWER_OFF :  prevOperation = STATE_POWER_OFF;
                                        returnToContinuousOperation = FALSE;
                                        break;
                case STATE_READY_ION :  // fall-through
                case STATE_ION_STOP :   prevOperation = STATE_READY_ION;
                                        returnToContinuousOperation = FALSE;
                                        break;
                case STATE_READY_STER : // fall-through
                case STATE_STER_STOP :  prevOperation = STATE_READY_STER;
                                        returnToContinuousOperation = FALSE;
                                        break;
                case STATE_READY_DIS :  // fall-through
                case STATE_DIS_STOP :   
                default :               prevOperation = STATE_READY_DIS;
                                        returnToContinuousOperation = FALSE;
                                        break;
              }
//              if (currentState==STATE_INIT) prevOperation = STATE_POWER_OFF;
//              else                          prevOperation = currentState;
  #endif  // INCLUDE_RETURN_TO_CONTINUOUS_MODE
              changeState(STATE_STER,FALSE);
              plasmaInfo.isScheduled = TRUE;
            }
#endif  // 0
          }
      }
    }
    if(pPointer != oldPpointer) {
      printf("%c", pBuf[oldPpointer]);
      if(++oldPpointer > MAX_SIZE_PRINT)
        oldPpointer = 0;
    }
  }
}

/**
  * @brief  Inserts a delay time.
  * @param  nTime: specifies the delay time length, in milliseconds.
  * @retval None
  */
void Delay(__IO uint32_t nTime)
{ 
  TimingDelay = nTime;

  while(TimingDelay != 0);
}

/**
  * @brief  Decrements the TimingDelay variable.
  * @param  None
  * @retval None
  */
void TimingDelay_Decrement(void)
{
  if (TimingDelay != 0x00)
  { 
    TimingDelay--;
  }
}

#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}

uint32_t sEE_TIMEOUT_UserCallback(void)
{
  
  printf("eeprom error11\r\n");
  
  /* Block communication and all processes */
  /*while (1)
  {   
  }  */
  return 0;
}

#endif

/**
  * @}
  */ 

/**
  * @}
  */ 

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
