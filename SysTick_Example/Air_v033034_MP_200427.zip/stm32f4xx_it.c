/***********************************************************************************************************************
 * Project      : õ���� ���� û����
 * Description  : �ö�� �� UV ������ �̿��� ���� �ҵ��⸦ �����ϴ� ���α׷�
 * Author       : ����
 * Date         : 2015-05-21
 * Version      : 0.01
 * History      :
  2015-05-21 - stm32f4�� systick ���α׷����� ���� ���� �ۼ�.
************************************************************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_it.h"
#include "main.h"
#include "Peripheral.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M4 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief   This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles PendSVC exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{
  TimingDelay_Decrement();
}

extern unsigned char continueOperation;    // SJM 190724 unify continue operation
extern unsigned int testLedBlink;
unsigned int testLedTimer = 0;
unsigned int ledTimer = 0;
unsigned int g_60hz;
//extern unsigned int G1_SF;
//extern unsigned int G2_SF;
//extern unsigned int G3_SF;
//extern unsigned int G4_SF;
extern unsigned int currentState;
extern unsigned int segBlinkOnTime;
extern unsigned char ozoneLampOnFlag;
extern unsigned char uvLampOnFlag;
extern unsigned char rciOnFlag;
extern unsigned char fan2OnFlag;
extern PLASMAINFO plasmaInfo;
extern DISINFO disInfo;
extern IONINFO ionInfo;

extern void readOzoneSensor();

#define OZONE_SENSOR_CHECK_TIME     1000     // SJM 190812 check ozone sensor every 500mSec.
                                              // SJM 190827 500 -> 1000
//PIR
//#define PID_CHECK_TIME 5000
#define PID_CHECK_TIME 1
#define PID_CHECK_INTERVAL          100     // SJM 190820 check PID sensor every 100mSec.
#define PID_CHECK_COUNT             3       // SJM 190820 check PID sensor at least 3 times
unsigned int pidDetectedStart;
unsigned int pidOnTime;
unsigned int pidCheckTimer = 0;             // SJM 190820 add to fix PID check routine
unsigned int pidCheckCount = 0;             // SJM 190820 add to fix PID check routine

//unsigned int pidLEDOnFlag = FALSE;      SJM 190711 always assigned to 'FALSE' & never used


//#define LED_ON_TIME 5000          SJM 190809 neverUsed
//unsigned int ledOnTime;           SJM 190809 neverUsed

//�Ҹ�ǰ ī���� 
unsigned int plusCounterMin;

unsigned int oneSecTimer;
//unsigned int fiveSecTimer;        SJM 190809 currently no Use.(used in commented code)

extern unsigned char pidDetect;

//Timer
int prepareTimer;
int destructionTimer;

//plasma blink
unsigned int plasmaBlinkOn = TRUE;
unsigned int plasmaBlinkOnTimer = 0;
unsigned int plasmaBlinkOnFlag = FALSE;
unsigned int plasmaBlinkOffTimer = 0;
unsigned int plasmaBlinkOffFlag;

unsigned int PlasmaOffTime = 0;

#ifdef  STAND_TYPE_ENABLE
//fan blink
unsigned int fanBlinkOn = TRUE;
unsigned int fanBlinkOnTimer = 0;
unsigned int fanBlinkOnFlag = FALSE;
unsigned int fanBlinkOffTimer = 0;
unsigned int fanBlinkOffFlag;
#endif
//ozonedetect
//extern unsigned char sterOzoneDetectFlag;     SJM 190711 never used

unsigned int dOzoneSensoredValue;

extern unsigned int g_extOzoneSenseFlag;
extern unsigned int g_remoteFlag;

unsigned long  sysTickCounter = 0;
unsigned char  halfSecFlag = FALSE;
unsigned short sensorCheck =0;

void TIM2_IRQHandler(void)
{
  TIM_ClearITPendingBit(TIM2, TIM_IT_Update);

//  sysTickCounter++;     // SJM 190703 add general system counter.
  if (halfSecFlag==FALSE) {
    sysTickCounter++;
    if (sysTickCounter>=500) {
      halfSecFlag = TRUE;
      sysTickCounter =0;
    }
  }
  //key Check
  timer_key_check();
  //Led On control
  if(++ledTimer > 2) {
    ledTimer = 0;
    if(++g_60hz > 4) {
      g_60hz = 0;
    }
    timerLed();
    if( currentState == STATE_STER ) {
        PIRLedTimer();
    }
    else if( !(currentState == STATE_POWER_OFF)) {
      WhiteLed();
    }
  }
  // ozone sensor check 
  if (++sensorCheck >= OZONE_SENSOR_CHECK_TIME) {
    sensorCheck = 0;
    readOzoneSensor();
  }
  //test timer and onesec Flag
  if(++testLedTimer > ONESEC) {
      testLedTimer = 0;
      testLedBlink = TRUE;
      oneSecFlag = TRUE;
//      dOzoneSensoredValue = getOzoneSensor();
  }
  if (++pidCheckTimer > PID_CHECK_INTERVAL) {
    pidCheckTimer = 0;
    if( (getPirPort1() == TRUE) || (getPirPort2() == TRUE) ) {
      if (++pidCheckCount>PID_CHECK_COUNT) {
        pidCheckCount = PID_CHECK_COUNT;
        pidDetect = TRUE;
        if(pidDetectedStart == FALSE) {
          pidDetectedStart = TRUE;
          pidOnTime++;
        }
        else {
          if(++pidOnTime > PID_CHECK_TIME) {
            pidDetectedStart = FALSE;
            pidOnTime = 0;
          }
        }
      }
    }
//    else if( (getPirPort1() == FALSE) && (getPirPort2() == FALSE) ) {
    else {
//      if (--pidCheckCount<=0) {
        pidCheckCount = 0;
        pidDetect = FALSE;
        if(pidDetectedStart == TRUE) {
          if(++pidOnTime > PID_CHECK_TIME) {
            pidDetectedStart = FALSE;
            pidOnTime = 0;
          } 
        }
//      }
    }
  }
    
  
  if(currentState == STATE_CONSUMABLE_WARNING) {
    if(segBlinkOnTime == TRUE) {
      if(++(sysConfig.blinkOnTimer) > 750) {
        sysConfig.blinkOnTimer = 0;
        sysConfig.blinkOnFlag = TRUE;
        segBlinkOnTime = FALSE;
      }
    }
    else {
      if(++(sysConfig.blinkOffTimer) > 250) {
        sysConfig.blinkOffTimer = 0;
        sysConfig.blinkOffFlag = TRUE;
        segBlinkOnTime = TRUE;
      }
    }
  } // end of (currentState == STATE_CONSUMABLE_WARNING)
  
  if (currentState == STATE_DESTRUCTION) {
    if(++oneSecTimer > ONESEC) {
      oneSecTimer = 0;
      if(destructionTimer >= 0) {
        destructionTimer--;
      }
      #ifdef  STAND_TYPE_ENABLE
      //FAN blink
      if(fanBlinkOn == TRUE) {
        if(++(fanBlinkOnTimer) > FAN_BLINK_ON_TIME) {
          fanBlinkOnTimer = 0;
          fanBlinkOnFlag = TRUE;
          fanBlinkOn = FALSE;
        }
      }
      else {
        if(++(fanBlinkOffTimer) > FAN_BLINK_OFF_TIME) {
          fanBlinkOffTimer = 0;
          fanBlinkOffFlag = TRUE;
          fanBlinkOn = TRUE;
        }
      }
      #endif
    }
    if(segBlinkOnTime == TRUE) {
      if(++(sysConfig.blinkOnTimer) > 750) {
        sysConfig.blinkOnTimer = 0;
        sysConfig.blinkOnFlag = TRUE;
        segBlinkOnTime = FALSE;
      }
    }
    else {
      if(++(sysConfig.blinkOffTimer) > 250) {
        sysConfig.blinkOffTimer = 0;
        sysConfig.blinkOffFlag = TRUE;
        segBlinkOnTime = TRUE;
      }
    }
  }     // end of (currentState == STATE_DESTRUCTION)
  
  if (currentState == STATE_PREPARE) {
    if(++oneSecTimer > ONESEC) {
      oneSecTimer = 0;
      if(prepareTimer >= 0) {
        prepareTimer--;
      }  
    }    
    if(segBlinkOnTime == TRUE) {
      if(++(sysConfig.blinkOnTimer) > 750) {
        sysConfig.blinkOnTimer = 0;
        sysConfig.blinkOnFlag = TRUE;
        segBlinkOnTime = FALSE;
      }
    }
    else
    {
      if(++(sysConfig.blinkOffTimer) > 250)
      {
        sysConfig.blinkOffTimer = 0;
        sysConfig.blinkOffFlag = TRUE;
        segBlinkOnTime = TRUE;
      }
    }
  }       // end of (currentState == STATE_PREPARE)
/*
#ifdef ADD_REMOTE_OZONE_SENSOR
    if(++fiveSecTimer > FIVESEC)
    {
      fiveSecTimer = 0;
      if(g_remoteFlag >= REMOTE_OZ1_FLAG)
      {
        g_extOzoneSenseFlag = TRUE;
        printf("\r\n g_extOzoneSenseFlag : TRUE");
      }
      else
      {
        g_extOzoneSenseFlag = FALSE;
        printf("\r\n g_extOzoneSenseFlag : FALSE");        
      }
    }  
#endif
*/
  //�� ���� �ð� ī��Ʈ �� ����, ����, ī����
//  if(currentState == STATE_STER || currentState == STATE_DIS ||  currentState == STATE_ION) {
    if(++plusCounterMin > ONESEC * 60) { //minite
      plusCounterMin = 0;
      if (fan2OnFlag)       sysConfig.filterCountMin++;     // SJM 190723 Fan1&2 run at the same time.
      if (rciOnFlag)        sysConfig.rciOperatingMin++;
      if (uvLampOnFlag)     sysConfig.uvLampCountMin++;
      if (ozoneLampOnFlag)  sysConfig.ozoneLampCountMin++;
    }
//  }   // end of "Time Count"

  //plasma mode Interrupt
  if((currentState == STATE_STER) || (currentState == STATE_READY_STER) || (currentState == STATE_STER_STOP)) {
    if(currentState == STATE_STER) {
      if (++plasmaInfo.plasmaOneSec > ONESEC) {
//        sterOzoneDetectFlag = TRUE;       SJM 190711 assigned but never used.
        plasmaInfo.plasmaOneSec = 0;
#ifdef  UNIFY_CONTINUE_OP
        if (plasmaInfo.plasmaTimer > 0 && continueOperation == FALSE)
#else
        if(plasmaInfo.plasmaTimer > 0 && plasmaInfo.continuation == FALSE)
#endif
          plasmaInfo.plasmaTimer--;
        //plasma blink
        if(plasmaBlinkOn == TRUE) {
          if(++(plasmaBlinkOnTimer) > PLASMA_BLINK_ON_TIME) {
            plasmaBlinkOnTimer = 0;
            plasmaBlinkOnFlag = TRUE;
            plasmaBlinkOn = FALSE;
          }
        }
        else {
          if(++(plasmaBlinkOffTimer) > PLASMA_BLINK_OFF_TIME) {
            plasmaBlinkOffTimer = 0;
            plasmaBlinkOffFlag = TRUE;
            plasmaBlinkOn = TRUE;
          }
        }
#ifdef  STAND_TYPE_ENABLE
        //FAN blink
        if(fanBlinkOn == TRUE) {
          if(++(fanBlinkOnTimer) > FAN_BLINK_ON_TIME) {
            fanBlinkOnTimer = 0;
            fanBlinkOnFlag = TRUE;
            fanBlinkOn = FALSE;
          }
        }
        else {
          if(++(fanBlinkOffTimer) > FAN_BLINK_OFF_TIME) {
            fanBlinkOffTimer = 0;
            fanBlinkOffFlag = TRUE;
            fanBlinkOn = TRUE;
          }
        }        
#endif        
      }   // end of (++plasmaInfo.plasmaOneSec > ONESEC)
#if 0     // SJM 190820 PID debuggging
      if( (getPirPort1() == TRUE) || (getPirPort2() == TRUE) ) {
        pidDetect = TRUE;
        if(pidDetectedStart == FALSE) {
          pidDetectedStart = TRUE;
          pidOnTime++;
        }
        else {
          if(++pidOnTime > PID_CHECK_TIME) {
            pidDetectedStart = FALSE;
            pidOnTime = 0;
          }
        }
      }
      else if( (getPirPort1() == FALSE) && (getPirPort2() == FALSE) ) {
        pidDetect = FALSE;
        if(pidDetectedStart == TRUE) {
          if(++pidOnTime > PID_CHECK_TIME) {
            pidDetectedStart = FALSE;
            pidOnTime = 0;
          } 
        }
      }
#endif
    }     // end of (currentState == STATE_STER)
    if(segBlinkOnTime == TRUE) {
      if(++(plasmaInfo.blinkOnTimer) > 750) {
        plasmaInfo.blinkOnTimer = 0;
        plasmaInfo.blinkOnFlag = TRUE;
        segBlinkOnTime = FALSE;
      }
    }
    else {
      if(++(plasmaInfo.blinkOffTimer) > 250) {
        plasmaInfo.blinkOffTimer = 0;
        plasmaInfo.blinkOffFlag = TRUE;
        segBlinkOnTime = TRUE;
      }
    }
  }       // end of 'plasma mode Interrupt'
  
  //Disinfect mode interrupt
  if(currentState == STATE_DIS || currentState == STATE_DIS_STOP || currentState == STATE_READY_DIS) {
    if(++disInfo.disOneSec > ONESEC && currentState == STATE_DIS) {
      disInfo.disOneSec = 0;
      if(disInfo.disTimer > 0)
        disInfo.disTimer--;
      #ifdef  STAND_TYPE_ENABLE
      //FAN blink
      if(fanBlinkOn == TRUE) {
        if(++(fanBlinkOnTimer) > FAN_BLINK_ON_TIME) {
          fanBlinkOnTimer = 0;
          fanBlinkOnFlag = TRUE;
          fanBlinkOn = FALSE;
        }
      }
      else {
        if(++(fanBlinkOffTimer) > FAN_BLINK_OFF_TIME) {
          fanBlinkOffTimer = 0;
          fanBlinkOffFlag = TRUE;
          fanBlinkOn = TRUE;
        }
      }        
      #endif
    }
    if(segBlinkOnTime == TRUE) {
      if(++(disInfo.blinkOnTimer) > 750) {
        disInfo.blinkOnTimer = 0;
        disInfo.blinkOnFlag = TRUE;
        segBlinkOnTime = FALSE;
      }
    }
    else {
      if(++(disInfo.blinkOffTimer) > 250) {
        disInfo.blinkOffTimer = 0;
        disInfo.blinkOffFlag = TRUE;
        segBlinkOnTime = TRUE;
      }
    }
  }         // END OF 'Disinfect mode interrupt'
  
  //ion mode interrupt
  if(currentState == STATE_ION || currentState == STATE_ION_STOP) {
    if(++ionInfo.ionOneSec > ONESEC && currentState == STATE_ION) {
      ionInfo.ionOneSec = 0;
      if(ionInfo.ionTimer > 0)
        ionInfo.ionTimer--;
      #ifdef  STAND_TYPE_ENABLE
      //FAN blink
      if(fanBlinkOn == TRUE) {
        if(++(fanBlinkOnTimer) > FAN_BLINK_ON_TIME) {
          fanBlinkOnTimer = 0;
          fanBlinkOnFlag = TRUE;
          fanBlinkOn = FALSE;
        }
      }
      else {
        if(++(fanBlinkOffTimer) > FAN_BLINK_OFF_TIME) {
          fanBlinkOffTimer = 0;
          fanBlinkOffFlag = TRUE;
          fanBlinkOn = TRUE;
        }
      }        
      #endif      
    }
    if(segBlinkOnTime == TRUE) {
      if(++(ionInfo.blinkOnTimer) > 750) {
        ionInfo.blinkOnTimer = 0;
        ionInfo.blinkOnFlag = TRUE;
        segBlinkOnTime = FALSE;
      }
    }
    else {
      if(++(ionInfo.blinkOffTimer) > 250) {
        ionInfo.blinkOffTimer = 0;
        ionInfo.blinkOffFlag = TRUE;
        segBlinkOnTime = TRUE;
      }
    }
  }     // end of "ion mode interrupt"
  
  if(voicePlayFlag == TRUE) {
    if(--g_voicePortDelay > 1) {
      GPIOA->BSRRH = GPIO_Pin_14;
    }
    else {
      GPIOA->BSRRL = GPIO_Pin_14; 
      voicePlayFlag = FALSE;
    }
  }
}

extern unsigned short m_count;
void TIM3_IRQHandler(void)
{
  TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
  remoteCheck();
}

extern unsigned char rx_buffer[];
extern unsigned char rx_head;
extern unsigned char rx_tail;
extern unsigned int setRTCFlag;

void USART3_IRQHandler(void)
{
  if(USART_GetITStatus(USART3, USART_IT_RXNE)!=RESET) { // && setRTCFlag == FALSE) { 
    rx_buffer[rx_head] = USART_ReceiveData(USART3);
    //printf("receive : %c\r\n", rx_buffer[rx_head]);
    if(++rx_head>=MAX_RX_BUFFER) 
      rx_head = 0;   
     USART_ClearITPendingBit(USART3,USART_IT_RXNE);
   }
}

/******************************************************************************/
/*                 STM32F4xx Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f4xx.s).                                               */
/******************************************************************************/

/**
  * @brief  This function handles PPP interrupt request.
  * @param  None
  * @retval None
  */
/*void PPP_IRQHandler(void)
{
}*/

/**
  * @}
  */ 

/**
  * @}
  */ 

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
