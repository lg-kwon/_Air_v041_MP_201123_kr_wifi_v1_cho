/**
  ******************************************************************************
  * @file    LED.h 
  * @author  sbKim
  * @version V1.0.0
  * @date    2015/05/21
  * @brief   Header for LED.h  module
  ******************************************************************************
**/
#ifndef __LED_H
#define __LED_H

#define LED_ON  1
#define LED_OFF 0

#define LED_PLASMA_FONT   1
#define LED_DIS_FONT      2
#define LED_ION_FONT      3
#define LED_RESERVE_FONT  4

#define LED_POWER_FONT    5
#define LED_PID_FONT      6

#define LED_POWER_SIG1    7
#define LED_POWER_SIG2    8
#define LED_MODE_SIG1     9
#define LED_MODE_SIG2     10

#define LED_SETTING_SIG1  11
#define LED_SETTING_SIG2  12

#define LED_PLASMA_ON     13
#define LED_DIS_ON        14
#define LED_ION_ON        15
#define LED_RESERVE_ON    16

#define LED_POWER_ON      17
#define LED_PID_ON        18


/* Includes ------------------------------------------------------------------*/
#include "main.h"
/* Exported types ------------------------------------------------------------*/

/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
void ledPortInit();
void ledControl(unsigned int control, unsigned char onoff);
void segmentControl(unsigned int num);
void ledComControl(unsigned char num, unsigned char onoff);
void timerLed();
void ledAllOff();
void segmentAlphaControl(unsigned char ch1, unsigned char ch2);
void PIRLedTimer();
void REDLed();
void WhiteLed();
#endif /* __LED_H */