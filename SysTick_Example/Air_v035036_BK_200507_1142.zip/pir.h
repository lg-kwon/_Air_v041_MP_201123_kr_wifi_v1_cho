#ifndef __PIR_H
#define __PIR_H

#include "main.h"

void pirInit();
unsigned int getPirPort1();
unsigned int getPirPort2();

#endif